import { Hono } from "hono";
import type { Client } from "@sdk/server-types";
import { tables, buckets, drizzleSchema } from "@generated";
import { eq, and, sql } from "drizzle-orm";
import Stripe from "stripe";
import { sanitizeReportHtml } from './email-safety';

// Re-export the required EdgeSpark bundle contract (tables/buckets/drizzleSchema).
export { tables, buckets, drizzleSchema };

function tryParse(json: string | null | undefined): any {
  if (!json) return {};
  try { return JSON.parse(json); } catch { return {}; }
}

/**
 * EdgeSpark entry point. All db/auth/secret/storage access happens exclusively
 * through the injected `edgespark` client — never via direct "edgespark"/"edgespark/http" imports.
 */
export async function createApp(edgespark: Client<typeof tables>): Promise<Hono> {
  const { db, secret, storage, auth } = edgespark;
  const getEnv = (): 'staging' | 'production' =>
    edgespark.getDeployEnv() as 'staging' | 'production';
  const stripeSecretName = () => getEnv() === 'production' ? 'STRIPE_SECRET_KEY' : 'SANDBOX_STRIPE_SECRET_KEY';
  const stripeWebhookSecretName = () => getEnv() === 'production' ? 'StripeSigningSecret' : 'SANDBOX_STRIPE_WEBHOOK_SECRET';
  const getStripeKey = () => {
    const environmentKey = secret.get(stripeSecretName());
    if (environmentKey) return environmentKey;
    // This project has no separate Stripe test-mode key. Staging QA therefore
    // uses the configured live key only for a session that is immediately
    // expired after verification; no charge is attempted.
    if (getEnv() === 'staging') {
      const liveKey = secret.get('STRIPE_SECRET_KEY');
      if (liveKey) console.warn('[STRIPE_QA] staging is using the configured live key; expire every QA session immediately');
      return liveKey;
    }
    return null;
  };

  // Customer-facing links must never derive from the worker request origin: webhook
  // requests arrive on a youbase.cloud worker (and staging deploys use staging--).
  // Keep the canonical app origin explicit so payment, report-ready, and welcome
  // emails always lead to the production SPA.
  const appBaseUrl = 'https://app.meinspect.com';
  const reportAccessUrl = (reportId: string) => `${appBaseUrl}/report/${encodeURIComponent(reportId)}`;

  type CheckoutSession = Stripe.Checkout.Session;

  function isConfirmedCheckout(session: CheckoutSession): boolean {
    return session.payment_status === 'paid' || session.payment_status === 'no_payment_required';
  }

  /**
   * The only Stripe path that may unlock a report. It is deliberately shared by
   * the signed webhook and authenticated reconciliation endpoints so a late or
   * missed webhook cannot strand a paid customer. Every required database write
   * is verified before success is returned; retries are safe because all writes
   * target the unique Stripe Checkout session/report pair.
   */
  async function confirmStripeCheckout(
    session: CheckoutSession,
    source: 'webhook' | 'webhook_fallback' | 'session_reconcile' | 'report_reconcile'
  ): Promise<{ paid: boolean; reportId: string; alreadyPaid: boolean }> {
    const reportId = session.metadata?.reportId || session.metadata?.inspectionId || '';
    if (!reportId) throw new Error(`Stripe session ${session.id} has no reportId metadata`);
    if (!isConfirmedCheckout(session)) {
      console.log(`[PAYMENT_CONFIRM] source=${source} session=${session.id} report=${reportId} status=${session.payment_status} action=pending`);
      return { paid: false, reportId, alreadyPaid: false };
    }

    const inspectionRows = await db.select().from(tables.inspections)
      .where(eq(tables.inspections.id, reportId));
    const inspection = inspectionRows[0];
    if (!inspection) {
      if (source === 'webhook') {
        console.warn(`[PAYMENT_CONFIRM] source=webhook session=${session.id} report=${reportId} action=missing_report_acknowledged`);
        return { paid: false, reportId, alreadyPaid: false };
      }
      throw new Error(`Report ${reportId} not found for Stripe session ${session.id}`);
    }

    const orderRows = await db.select().from(tables.orders)
      .where(eq(tables.orders.providerSessionId, session.id));
    const order = orderRows[0];
    if (!order) throw new Error(`Pending order not found for Stripe session ${session.id}`);
    if (order.inspectionId && order.inspectionId !== reportId) {
      throw new Error(`Stripe session ${session.id} report metadata does not match pending order`);
    }

    if (order.userId !== inspection.userId) {
      throw new Error(`Stripe session ${session.id} owner does not match report ${reportId}`);
    }

    const currentPayment = tryParse(inspection.paymentData as string);
    const wasAlreadyPaid = currentPayment?.paid === true;
    const now = Math.floor(Date.now() / 1000);
    const amount = session.amount_total == null ? order.amount : session.amount_total / 100;
    const currency = (session.currency || order.currency || 'AED').toUpperCase();
    const paymentIntent = typeof session.payment_intent === 'string' ? session.payment_intent : null;

    const updatedOrders = await db.update(tables.orders)
      .set({
        status: 'paid',
        amount,
        currency,
        providerPaymentId: paymentIntent,
        paidAt: order.paidAt || now,
      })
      .where(eq(tables.orders.id, order.id))
      .returning();
    if (updatedOrders.length !== 1 || updatedOrders[0].status !== 'paid') {
      throw new Error(`Order update failed for Stripe session ${session.id}`);
    }

    const nextPayment = {
      ...currentPayment,
      paid: true,
      provider: 'stripe',
      sessionId: session.id,
      paymentIntentId: paymentIntent,
      amount,
      currency,
      paidAt: currentPayment?.paidAt || now,
      confirmedAt: now,
      confirmedBy: source,
    };

    // The paid=false -> paid=true transition is conditional at the database
    // layer. Concurrent duplicate deliveries can therefore produce only one
    // unlock (and only that winner sends the unlock email).
    let didUnlock = false;
    if (!wasAlreadyPaid) {
      const updatedInspections = await db.update(tables.inspections)
        .set({ paymentData: JSON.stringify(nextPayment) })
        .where(and(
          eq(tables.inspections.id, reportId),
          sql`COALESCE(json_extract(${tables.inspections.paymentData}, '$.paid'), 0) != 1`
        ))
        .returning();
      didUnlock = updatedInspections.length === 1;
      if (!didUnlock) {
        const latest = await db.select().from(tables.inspections)
          .where(eq(tables.inspections.id, reportId));
        if (tryParse(latest[0]?.paymentData as string)?.paid !== true) {
          throw new Error(`Report unlock failed for ${reportId}`);
        }
      }
    }

    const alreadyPaid = wasAlreadyPaid || !didUnlock;
    console.log(`[PAYMENT_CONFIRM] source=${source} session=${session.id} report=${reportId} action=${didUnlock ? 'unlocked' : 'idempotent'}`);

    if (didUnlock) {
      const userRows = await db.select().from(tables.users).where(eq(tables.users.id, inspection.userId));
      const user = userRows[0];
      if (user?.email) {
        const subject = `Your report is unlocked (RPT-${reportId.slice(0, 8).toUpperCase()})`;
        const html = `<div style="font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',Roboto,sans-serif;max-width:600px;margin:0 auto;padding:32px"><h1 style="color:#1e293b">Your report is unlocked</h1><p>Hi ${user.name || 'there'},</p><p>Your report is ready to access.</p><p><strong>Report ID:</strong> RPT-${reportId.slice(0, 8).toUpperCase()}</p><p><a href="${reportAccessUrl(reportId)}" style="display:inline-block;background:#2563eb;color:#fff;padding:12px 24px;border-radius:8px;text-decoration:none;font-weight:600">Access Your Report</a></p></div>`;
        const emailResult = await sendNotificationEmail(user.email, subject, html);
        if (emailResult.ok) {
          await db.update(tables.inspections)
            .set({ paymentData: JSON.stringify({ ...nextPayment, confirmationEmailSentAt: now }) })
            .where(and(
              eq(tables.inspections.id, reportId),
              sql`json_extract(${tables.inspections.paymentData}, '$.sessionId') = ${session.id}`
            ));
        } else {
          console.error(`[PAYMENT_CONFIRM] unlock email failed session=${session.id} report=${reportId}: ${emailResult.error || 'unknown error'}`);
        }
      }
    }

    return { paid: true, reportId, alreadyPaid };
  }

  /**
   * Verify that the authenticated user owns the given inspection.
   * Returns the inspection row if authorized, or null otherwise.
   */
  async function requireOwnership(
    userId: string,
    inspectionId: string
  ): Promise<any | null> {
    const rows = await db
      .select()
      .from(tables.inspections)
      .where(
        and(
          eq(tables.inspections.id, inspectionId),
          eq(tables.inspections.userId, userId)
        )
      );
    if (rows.length === 0) return null;
    return rows[0];
  }

  const app = new Hono();

  // Register before every admin route, including routes declared in other sections.
  // Only the configured IDs or the existing server-managed admin flag grant access.
  app.use('/api/admin/*', async (c, next) => {
    if (!await requireAdmin()) return c.json({ error: 'Admin access required' }, 403);
    await next();
  });

  // Defense-in-depth for every worker response, including errors and public routes.
  app.use('*', async (c, next) => {
    await next();
    c.header('Content-Security-Policy', "default-src 'self'; base-uri 'self'; object-src 'none'; frame-ancestors 'none'; form-action 'self'; script-src 'self' 'unsafe-inline'; style-src 'self' 'unsafe-inline'; img-src 'self' data: blob: https:; font-src 'self' data:; connect-src 'self' https://api.stripe.com https://*.youbase.cloud; frame-src https://js.stripe.com https://hooks.stripe.com; upgrade-insecure-requests");
    c.header('Strict-Transport-Security', 'max-age=63072000; includeSubDomains; preload');
    c.header('X-Content-Type-Options', 'nosniff');
    c.header('X-Frame-Options', 'DENY');
    c.header('Referrer-Policy', 'strict-origin-when-cross-origin');
    c.header('Permissions-Policy', 'camera=(self), geolocation=(self), microphone=(), payment=(self)');
  });

  // Global error handler
  app.onError((err, c) => {
    console.error("[API] error:", err);
    return c.json({ error: err instanceof Error ? err.message : "Internal error" }, 500);
  });

  // ==================== NATIVE MOBILE OAUTH ====================
  // OAuth must start inside the same browser context that will receive Google's
  // callback. Capacitor's WebView has an isolated cookie jar, so native apps open
  // this public bootstrap page in a system browser instead of starting OAuth in
  // the WebView.
  app.get('/api/public/mobile-auth/google', (c) => {
    const origin = new URL(c.req.url).origin;
    const callbackURL = `${origin}/api/public/mobile-auth/callback`;

    return c.html(`<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width,initial-scale=1" />
  <meta name="color-scheme" content="light" />
  <title>Continue with Google — MeInspect</title>
  <style>
    body{margin:0;min-height:100vh;display:grid;place-items:center;background:#f8fafc;color:#0f172a;font:16px system-ui,-apple-system,sans-serif}
    main{width:min(88vw,360px);text-align:center}.spinner{width:38px;height:38px;margin:0 auto 20px;border:4px solid #bfdbfe;border-top-color:#2563eb;border-radius:50%;animation:spin .8s linear infinite}
    p{color:#64748b;line-height:1.5}.error{color:#b91c1c}button{border:0;border-radius:12px;padding:12px 18px;background:#2563eb;color:white;font-weight:700}@keyframes spin{to{transform:rotate(360deg)}}
  </style>
</head>
<body><main><div class="spinner" aria-hidden="true"></div><h1>Opening Google sign-in</h1><p id="status">Please wait…</p></main>
<script>
(async function () {
  const status = document.getElementById('status');
  try {
    const response = await fetch('/api/_es/auth/sign-in/social', {
      method: 'POST',
      credentials: 'include',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        provider: 'google',
        callbackURL: ${JSON.stringify(callbackURL)},
        disableRedirect: true
      })
    });
    const result = await response.json();
    if (!response.ok || !result.url) throw new Error(result.message || 'Unable to start Google sign-in');

    // Re-issue Better Auth's temporary state cookie with native-safe flags.
    // Its value remains HttpOnly and never enters JavaScript.
    const cookieResponse = await fetch('/api/public/mobile-auth/secure-state', {
      method: 'POST',
      credentials: 'include'
    });
    if (!cookieResponse.ok) throw new Error('Unable to secure the sign-in session');

    window.location.replace(result.url);
  } catch (error) {
    document.querySelector('.spinner').remove();
    status.className = 'error';
    status.textContent = error instanceof Error ? error.message : 'Google sign-in could not be started.';
  }
})();
</script></body></html>`);
  });

  // Better Auth creates this short-lived CSRF/state cookie. Re-issuing the same
  // HttpOnly value with SameSite=None + Secure allows Google's cross-site return
  // while keeping the state unavailable to page scripts.
  app.post('/api/public/mobile-auth/secure-state', (c) => {
    const cookieHeader = c.req.header('Cookie') || '';
    const stateCookie = cookieHeader
      .split(';')
      .map((cookie) => cookie.trim())
      .find((cookie) => cookie.startsWith('better-auth.state='));

    if (!stateCookie) {
      return c.json({ error: 'OAuth state cookie was not initialized' }, 400);
    }

    const stateValue = stateCookie.slice('better-auth.state='.length);
    if (!stateValue || /[\r\n;]/.test(stateValue)) {
      return c.json({ error: 'Invalid OAuth state cookie' }, 400);
    }

    c.header(
      'Set-Cookie',
      `better-auth.state=${stateValue}; Max-Age=300; Path=/; HttpOnly; Secure; SameSite=None`
    );
    c.header('Cache-Control', 'no-store');
    return c.body(null, 204);
  });

  // YouBase appends es_auth_token after the provider callback. Send it back to
  // the native app through its registered custom URL scheme.
  app.get('/api/public/mobile-auth/callback', (c) => {
    const deepLink = new URL('meinspect://auth/callback');
    const token = c.req.query('es_auth_token');
    const error = c.req.query('error');
    const errorDescription = c.req.query('error_description');

    if (token) deepLink.searchParams.set('es_auth_token', token);
    if (error) deepLink.searchParams.set('error', error);
    if (errorDescription) deepLink.searchParams.set('error_description', errorDescription);

    return c.html(`<!doctype html>
<html lang="en"><head><meta charset="utf-8" /><meta name="viewport" content="width=device-width,initial-scale=1" />
<title>Return to MeInspect</title><style>body{margin:0;min-height:100vh;display:grid;place-items:center;background:#f8fafc;font:16px system-ui;color:#0f172a}main{text-align:center;padding:24px}a{display:inline-block;margin-top:12px;padding:12px 18px;border-radius:12px;background:#2563eb;color:#fff;text-decoration:none;font-weight:700}</style></head>
<body><main><h1>Sign-in complete</h1><p>Return to MeInspect to continue.</p><a id="open-app" href=${JSON.stringify(deepLink.toString())}>Open MeInspect</a></main>
<script>window.location.replace(${JSON.stringify(deepLink.toString())});</script></body></html>`);
  });

  // ==================== USER PROFILE ENDPOINTS ====================
  // Authenticated endpoints — use auth.user for identity

  // Save/update user profile (phone, location) — authenticated
  app.post('/api/user/profile', async (c) => {
    const userId = auth.user!.id;
    const userEmail = auth.user!.email || '';
    const { name, phone, location } = await c.req.json();

    const existing = await db.select().from(tables.users)
      .where(eq(tables.users.id, userId));

    if (existing.length > 0) {
      await db.update(tables.users).set({
        name: name !== undefined ? name : existing[0].name,
        phone: phone !== undefined ? phone : existing[0].phone,
        location: location !== undefined ? location : existing[0].location,
        email: userEmail || existing[0].email,
        updatedAt: new Date().toISOString(),
      }).where(eq(tables.users.id, userId));
    } else {
      // Create user record if it doesn't exist yet
      await db.insert(tables.users).values({
        id: userId,
        email: userEmail,
        name: name || auth.user!.name || '',
        phone: phone || '',
        location: location || '',
      });
    }
    return c.json({ success: true });
  });

  // Delete user account and all associated data
  app.delete('/api/user/account', async (c) => {
    if (!auth.user) return c.json({ error: 'Unauthorized' }, 401);
    const userId = auth.user!.id;

    try {
      // Never cascade-delete financial records through account deletion either.
      // Retain paid/finalised evidence; delete only disposable drafts.
      await db.delete(tables.inspections).where(and(
        eq(tables.inspections.userId, userId),
        sql`COALESCE(json_extract(CASE WHEN json_valid(${tables.inspections.paymentData}) THEN ${tables.inspections.paymentData} ELSE '{}' END, '$.paid'), 0) NOT IN (1, 'true')`,
        sql`${tables.inspections.status} NOT IN ('completed', 'finalised', 'finalized')`,
        sql`COALESCE(${tables.inspections.reportGenerated}, 0) = 0`,
        sql`COALESCE(${tables.inspections.completedAt}, '') = ''`,
        sql`NOT EXISTS (SELECT 1 FROM ${tables.reportVerifications} WHERE ${tables.reportVerifications.inspectionId} = ${tables.inspections.id})`,
        sql`NOT EXISTS (SELECT 1 FROM ${tables.orders} WHERE ${tables.orders.inspectionId} = ${tables.inspections.id} AND ${tables.orders.status} = 'paid')`,
        sql`NOT EXISTS (SELECT 1 FROM ${tables.payments} WHERE ${tables.payments.inspectionId} = ${tables.inspections.id})`
      ));

      // Delete the app-level user record
      await db.delete(tables.users)
        .where(eq(tables.users.id, userId));

      // Delete the user's profile row (was previously left behind).
      try {
        await db.delete(tables.userProfiles)
          .where(eq(tables.userProfiles.userId, userId));
      } catch (profileErr) {
        console.warn('[ACCOUNT] user_profiles cleanup failed (non-fatal):', profileErr);
      }

      // CRITICAL BUG FIX: previously this endpoint only removed the app-level
      // `users`/`inspections` rows and returned success — but it NEVER deleted
      // the actual authentication account (`es_system__auth_user`). The result:
      // the user could still log in afterwards, and their email stayed
      // permanently "taken" (re-registration failed with a duplicate email),
      // so "Delete Account" was effectively a silent no-op. We now delete the
      // auth identity itself, which truly removes the account and frees the
      // email for re-use.
      await db.delete(tables.esSystemAuthUser)
        .where(eq(tables.esSystemAuthUser.id, userId));

      console.log(`[ACCOUNT] Deleted auth identity and disposable data; retained financial/finalised records for user: ${userId}`);
      return c.json({ success: true, message: 'Account and all associated data deleted successfully' });
    } catch (err) {
      console.error('[ACCOUNT] Error deleting account:', err);
      return c.json({ error: 'Failed to delete account' }, 500);
    }
  });

  // Get own user profile — authenticated
  app.get('/api/user/profile', async (c) => {
    const userId = auth.user!.id;
    const result = await db.select().from(tables.users)
      .where(eq(tables.users.id, userId));
    if (result.length === 0) return c.json({ data: null });
    return c.json({ data: result[0] });
  });

  // ==================== INSPECTION ENDPOINTS ====================
  // All /api/* routes enforce authentication via Youbase.
  // Additional ownership checks prevent IDOR.

  // List inspections for authenticated user
  app.get('/api/inspections', async (c) => {
    const userId = auth.user!.id;
    const inspections = await db.select().from(tables.inspections)
      .where(eq(tables.inspections.userId, userId));
    return c.json({ data: inspections });
  });

  // Get single inspection — ownership check
  app.get('/api/inspections/:id', async (c) => {
    const userId = auth.user!.id;
    const id = c.req.param('id');
    const row = await requireOwnership(userId, id);
    if (!row) return c.json({ error: 'Not found' }, 404);
    return c.json({ data: row });
  });

  // Create inspection
  app.post('/api/inspections', async (c) => {
    const data = await c.req.json();
    const userId = auth.user!.id;

    const inspection = await db.insert(tables.inspections).values({
      id: data.id,
      userId,
      propertyType: data.propertyType || 'apartment',
      status: data.status || 'draft',
      generalNotes: data.generalNotes || '',
      propertyData: JSON.stringify(data.property || {}),
      tenantData: JSON.stringify(data.tenant || {}),
      landlordData: JSON.stringify(data.landlord || {}),
      agentData: JSON.stringify(data.agent || {}),
      tenancyData: JSON.stringify(data.tenancy || {}),
      roomsData: JSON.stringify(data.rooms || []),
      propertyItems: JSON.stringify(data.propertyItems || []),
      signatures: JSON.stringify(data.signatures || []),
      overallPhotos: JSON.stringify(data.overallPhotos || []),
      // Payment status cannot be set directly via API for security reasons.
      paymentData: JSON.stringify({ paid: false }),
      reportGenerated: data.reportGenerated ? 1 : 0,
      pdfUrl: data.pdfUrl || '',
      extraData: JSON.stringify(data.extra || {}),
      createdAt: data.createdAt || new Date().toISOString(),
      updatedAt: data.updatedAt || new Date().toISOString(),
    }).returning();

    return c.json({ data: inspection[0] }, 201);
  });

  // Update inspection — ownership check
  app.put('/api/inspections/:id', async (c) => {
    const userId = auth.user!.id;
    const id = c.req.param('id');
    const data = await c.req.json();

    // Ownership check
    const existing = await requireOwnership(userId, id);
    if (!existing) return c.json({ error: 'Inspection not found' }, 404);

    const updateData: Record<string, any> = { updatedAt: new Date().toISOString() };
    if (data.status !== undefined) updateData.status = data.status;
    if (data.generalNotes !== undefined) updateData.generalNotes = data.generalNotes;
    if (data.property !== undefined) updateData.propertyData = JSON.stringify(data.property);
    if (data.tenant !== undefined) updateData.tenantData = JSON.stringify(data.tenant);
    if (data.landlord !== undefined) updateData.landlordData = JSON.stringify(data.landlord);
    if (data.agent !== undefined) updateData.agentData = JSON.stringify(data.agent);
    if (data.tenancy !== undefined) updateData.tenancyData = JSON.stringify(data.tenancy);
    if (data.rooms !== undefined) updateData.roomsData = JSON.stringify(data.rooms);
    if (data.propertyItems !== undefined) updateData.propertyItems = JSON.stringify(data.propertyItems);
    if (data.signatures !== undefined) updateData.signatures = JSON.stringify(data.signatures);
    if (data.overallPhotos !== undefined) updateData.overallPhotos = JSON.stringify(data.overallPhotos);
    // Payment status cannot be set directly via API for security reasons.
    // It must be updated via Stripe webhook or internal logic.
    if (data.reportGenerated !== undefined) updateData.reportGenerated = data.reportGenerated ? 1 : 0;
    if (data.completedAt !== undefined) updateData.completedAt = data.completedAt;
    if (data.pdfUrl !== undefined) updateData.pdfUrl = data.pdfUrl;
    if (data.extra !== undefined) updateData.extraData = JSON.stringify(data.extra);
    if (data.updatedAt) updateData.updatedAt = data.updatedAt;

    await db.update(tables.inspections).set(updateData)
      .where(eq(tables.inspections.id, id));
    return c.json({ success: true });
  });

  // Delete inspection — ownership check. Paid and finalised reports are immutable.
  app.delete('/api/inspections/:id', async (c) => {
    const userId = auth.user!.id;
    const id = c.req.param('id');
    const existing = await requireOwnership(userId, id);
    if (!existing) return c.json({ error: 'Inspection not found' }, 404);

    const payment = tryParse(existing.paymentData as string);
    const finalised = existing.status === 'completed'
      || existing.status === 'finalised'
      || existing.status === 'finalized'
      || existing.reportGenerated === 1
      || !!existing.completedAt;
    if (payment?.paid === true || finalised) {
      return c.json({
        error: 'Paid or finalised inspections cannot be deleted. Keep the report for your records.',
      }, 409);
    }

    // Check authoritative related records in the DELETE itself, closing the
    // read/delete race. payments has ON DELETE CASCADE, so even an unpaid payment
    // record must block physical deletion. Orders/payments are never deleted here.
    const deleted = await db.delete(tables.inspections).where(and(
      eq(tables.inspections.id, id),
      eq(tables.inspections.userId, userId),
      sql`COALESCE(json_extract(CASE WHEN json_valid(${tables.inspections.paymentData}) THEN ${tables.inspections.paymentData} ELSE '{}' END, '$.paid'), 0) NOT IN (1, 'true')`,
      sql`${tables.inspections.status} NOT IN ('completed', 'finalised', 'finalized')`,
      sql`COALESCE(${tables.inspections.reportGenerated}, 0) = 0`,
      sql`COALESCE(${tables.inspections.completedAt}, '') = ''`,
      sql`NOT EXISTS (SELECT 1 FROM ${tables.reportVerifications} WHERE ${tables.reportVerifications.inspectionId} = ${id})`,
      sql`NOT EXISTS (SELECT 1 FROM ${tables.orders} WHERE ${tables.orders.inspectionId} = ${id} AND ${tables.orders.status} = 'paid')`,
      sql`NOT EXISTS (SELECT 1 FROM ${tables.payments} WHERE ${tables.payments.inspectionId} = ${id})`
    )).returning({ id: tables.inspections.id });
    if (deleted.length === 0) {
      return c.json({ error: 'Paid or finalised inspections, or inspections with payment records, cannot be deleted. Keep the report for your records.' }, 409);
    }
    return c.json({ success: true });
  });

  // ==================== EMAIL ENDPOINTS ====================

  const EMAIL_REGEX = /^[a-zA-Z0-9._%+\-]+@[a-zA-Z0-9.\-]+\.[a-zA-Z]{2,}$/;
  const escapeEmailText = (value: unknown): string => String(value ?? '')
    .replaceAll('&', '&amp;')
    .replaceAll('<', '&lt;')
    .replaceAll('>', '&gt;')
    .replaceAll('"', '&quot;')
    .replaceAll("'", '&#39;');

  const inspectionContacts = (inspection: any): string[] => {
    const extra = tryParse(inspection.extraData);
    return [
      tryParse(inspection.tenantData).email,
      tryParse(inspection.landlordData).email,
      tryParse(inspection.agentData).email,
      extra?.meta?.inspectorEmail,
    ].filter((email): email is string => typeof email === 'string' && EMAIL_REGEX.test(email));
  };

  // One atomic INSERT ... SELECT reserves capacity. Rejected attempts do not
  // consume quota; parallel workers cannot oversubscribe the rolling-hour cap.
  // Legacy requests have no inspectionId: an empty string keeps the existing
  // NOT NULL column and avoids inventing an inspection or changing the schema.
  async function reserveEmailRecipients(userId: string, inspectionId: string, count: number): Promise<boolean> {
    const now = Math.floor(Date.now() / 1000);
    const eventId = crypto.randomUUID();
    await db.run(sql`INSERT INTO email_send_events (id, user_id, inspection_id, recipient_count, sent_at)
      SELECT ${eventId}, ${userId}, ${inspectionId}, ${count}, ${now}
      WHERE (SELECT COALESCE(SUM(recipient_count), 0) FROM email_send_events
        WHERE user_id = ${userId} AND sent_at > ${now - 3600}) + ${count} <= 30`);
    const reserved = await db.select().from(tables.emailSendEvents)
      .where(eq(tables.emailSendEvents.id, eventId));
    return reserved.length === 1;
  }

  // Both contracts are permanent: installed v9/web clients send to/subject/html;
  // newer clients may send inspectionId. Never require a v9 client upgrade.
  app.post('/api/send-email', async (c) => {
    const userId = auth.user!.id;
    const body = await c.req.json().catch(() => null) as Record<string, unknown> | null;
    if (!body || Array.isArray(body) || typeof body !== 'object') {
      return c.json({ error: 'to, subject, and html are required' }, 400);
    }

    if ('to' in body || 'subject' in body || 'html' in body) {
      const { to, subject, html } = body;
      if (!to || typeof subject !== 'string' || !subject || typeof html !== 'string' || !html) {
        return c.json({ error: 'to, subject, and html are required' }, 400);
      }
      const recipients = Array.isArray(to) ? to : [to];
      const invalid = recipients.filter(email => typeof email !== 'string' || !EMAIL_REGEX.test(email));
      if (invalid.length) return c.json({ error: `Invalid email address(es): ${invalid.join(', ')}` }, 400);
      if (!recipients.length) return c.json({ error: 'At least one recipient is required' }, 400);
      const htmlBytes = new TextEncoder().encode(html).length;
      if (htmlBytes > 8 * 1024 * 1024) {
        return c.json({ error: `Email content too large (${(htmlBytes / (1024 * 1024)).toFixed(1)} MB). Please compress images before sending. Maximum allowed: 8 MB.` }, 413);
      }
      if (!secret.get('RESEND_API_KEY')) {
        return c.json({ error: 'Email service not configured (RESEND_API_KEY missing)' }, 500);
      }

      // Live UI and restored v9-compatible modal only offer inspection contacts;
      // neither has a free-text recipient field. The legacy body has no report ID,
      // so match contacts across all inspections owned by this authenticated user.
      const owned = await db.select().from(tables.inspections)
        .where(eq(tables.inspections.userId, userId));
      const allowed = new Set([auth.user!.email || '', ...owned.flatMap(inspectionContacts)]
        .map(email => email.toLowerCase()));
      if (recipients.some(email => !allowed.has(String(email).toLowerCase()))) {
        return c.json({ error: 'Recipients must be your own email address or contacts on your inspections.' }, 403);
      }

      const safeHtml = sanitizeReportHtml(html);
      if (!await reserveEmailRecipients(userId, '', recipients.length)) {
        c.header('Retry-After', '3600');
        return c.json({ error: 'Email limit reached. You can send at most 30 emails per hour.' }, 429);
      }
      const results: { email: string; success: boolean; id?: string; error?: string }[] = [];
      for (const email of recipients as string[]) {
        // sendNotificationEmail uses FROM_EMAIL or the server fallback only.
        const result = await sendNotificationEmail(email, subject, safeHtml);
        console.log('[EMAIL_REPORT]', { userId, format: 'legacy', email, success: result.ok, id: result.id, error: result.error });
        results.push({ email, success: result.ok, ...(result.ok ? { id: result.id } : { error: result.error }) });
      }
      const allSuccess = results.every(result => result.success);
      // Preserve legacy HTTP 200 even for provider/partial failure; clients read
      // success/results, and the original response always used this shape.
      return c.json({
        success: allSuccess,
        results,
        sentCount: results.filter(result => result.success).length,
        failedCount: results.filter(result => !result.success).length,
        ...(allSuccess ? {} : { error: results.find(result => !result.success)?.error || '' }),
      });
    }

    if (typeof body.inspectionId !== 'string' || !body.inspectionId.trim()) {
      return c.json({ error: 'inspectionId or to, subject, and html are required' }, 400);
    }

    const inspectionId = body.inspectionId.trim();
    const inspection = await requireOwnership(userId, inspectionId);
    if (!inspection) return c.json({ error: 'Inspection not found' }, 404);

    const tenant = tryParse(inspection.tenantData as string);
    const landlord = tryParse(inspection.landlordData as string);
    const agent = tryParse(inspection.agentData as string);
    const property = tryParse(inspection.propertyData as string);
    const extra = tryParse(inspection.extraData as string);
    const listed = [tenant, landlord, agent, extra?.meta]
      .map((party: any) => ({ name: party?.name || party?.inspectorName || '', email: party?.email || party?.inspectorEmail || '' }))
      .filter((party: any) => EMAIL_REGEX.test(String(party.email || '')));
    const allRecipients = [
      ...listed,
      { name: auth.user!.name || 'Inspector', email: auth.user!.email || '' },
    ];
    const recipients = [...new Map(
      allRecipients
        .filter(party => EMAIL_REGEX.test(String(party.email || '')))
        .map(party => [String(party.email).toLowerCase(), { name: String(party.name || ''), email: String(party.email) }])
    ).values()];
    if (recipients.length === 0) return c.json({ error: 'No valid inspection recipient email addresses were found' }, 422);

    if (!await reserveEmailRecipients(userId, inspectionId, recipients.length)) {
      c.header('Retry-After', '3600');
      return c.json({ error: 'Email limit reached. You can send at most 30 emails per hour.' }, 429);
    }

    const reportCode = `RPT-${inspectionId.slice(0, 8).toUpperCase()}`;
    const propertyName = property.buildingName || property.area || 'Property inspection';
    const addressParts = [property.unitNumber, property.buildingName, property.area, property.city].filter(Boolean);
    const subject = `MeInspect report ${reportCode}`;
    const html = `<div style="font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',Roboto,sans-serif;max-width:600px;margin:0 auto;padding:32px;color:#1e293b"><h1 style="font-size:24px">Inspection report ready</h1><p>The MeInspect report for <strong>${escapeEmailText(propertyName)}</strong> is ready.</p><p><strong>Report ID:</strong> ${escapeEmailText(reportCode)}</p>${addressParts.length ? `<p><strong>Property:</strong> ${escapeEmailText(addressParts.join(', '))}</p>` : ''}<p><a href="${reportAccessUrl(inspectionId)}" style="display:inline-block;background:#2563eb;color:#fff;padding:12px 24px;border-radius:8px;text-decoration:none;font-weight:600">Open report</a></p><p style="color:#64748b;font-size:13px">This message was sent from MeInspect using the contact details recorded on the inspection.</p></div>`;

    const results = [] as { email: string; success: boolean; id?: string; error?: string }[];
    for (const recipient of recipients) {
      const result = await sendNotificationEmail(recipient.email, subject, html);
      console.log('[EMAIL_REPORT]', { userId, inspectionId, format: 'inspectionId', email: recipient.email, success: result.ok, id: result.id, error: result.error });
      results.push({ email: recipient.email, success: result.ok, id: result.id, error: result.error });
    }
    const sentCount = results.filter(result => result.success).length;
    const failedCount = results.length - sentCount;
    return c.json({
      success: failedCount === 0,
      sentCount,
      failedCount,
      results,
      ...(failedCount ? { error: results.find(result => !result.success)?.error || 'Some emails could not be sent' } : {}),
    }, failedCount === results.length ? 502 : 200);
  });

  // ==================== INSPECTION HISTORY SYNC ====================

  // Sync all inspection data from backend (full sync)
  app.get('/api/sync/inspections', async (c) => {
    const userId = auth.user!.id;

    const inspections = await db.select().from(tables.inspections)
      .where(eq(tables.inspections.userId, userId));

    // Parse JSON fields back to objects
    const parsed = inspections.map((row: any) => ({
      id: row.id,
      userId: row.userId,
      propertyType: row.propertyType,
      status: row.status,
      generalNotes: row.generalNotes,
      reportGenerated: row.reportGenerated,
      pdfUrl: row.pdfUrl || '',
      createdAt: row.createdAt,
      updatedAt: row.updatedAt,
      completedAt: row.completedAt,
      property: tryParse(row.propertyData),
      tenant: tryParse(row.tenantData),
      landlord: tryParse(row.landlordData),
      agent: tryParse(row.agentData),
      tenancy: tryParse(row.tenancyData),
      rooms: tryParse(row.roomsData),
      propertyItems: tryParse(row.propertyItems),
      signatures: tryParse(row.signatures),
      overallPhotos: tryParse(row.overallPhotos),
      payment: tryParse(row.paymentData),
      extra: tryParse(row.extraData),
    }));

    return c.json({ data: parsed, count: parsed.length });
  });

  // Batch sync: upload multiple inspections from frontend
  app.post('/api/sync/push', async (c) => {
    const userId = auth.user!.id;
    const { inspections: items } = await c.req.json();
    if (!Array.isArray(items)) return c.json({ error: 'inspections array required' }, 400);

    let created = 0;
    let updated = 0;

    for (const inspection of items) {
      try {
        // Check if inspection belongs to this user
        const existing = await db.select().from(tables.inspections)
          .where(
            and(
              eq(tables.inspections.id, inspection.id),
              eq(tables.inspections.userId, userId)
            )
          );

        const updateData: Record<string, any> = {
          status: inspection.status,
          generalNotes: inspection.generalNotes || '',
          propertyType: inspection.propertyType || 'apartment',
          propertyData: JSON.stringify(inspection.property || {}),
          tenantData: JSON.stringify(inspection.tenant || {}),
          landlordData: JSON.stringify(inspection.landlord || {}),
          agentData: JSON.stringify(inspection.agent || {}),
          tenancyData: JSON.stringify(inspection.tenancy || {}),
          roomsData: JSON.stringify(inspection.rooms || []),
          propertyItems: JSON.stringify(inspection.propertyItems || []),
          signatures: JSON.stringify(inspection.signatures || []),
          overallPhotos: JSON.stringify(inspection.overallPhotos || []),
          // Payment status cannot be pushed from client for security reasons.
          reportGenerated: inspection.reportGenerated ? 1 : 0,
          pdfUrl: inspection.pdfUrl || '',
          extraData: JSON.stringify(inspection.extra || {}),
          updatedAt: new Date().toISOString(),
        };
        if (inspection.completedAt) updateData.completedAt = inspection.completedAt;

        if (existing.length > 0) {
          await db.update(tables.inspections)
            .set(updateData)
            .where(eq(tables.inspections.id, inspection.id));
          updated++;
        } else {
          await db.insert(tables.inspections).values({
            id: inspection.id,
            userId,
            ...updateData,
            createdAt: inspection.createdAt || new Date().toISOString(),
          });
          created++;
        }
      } catch (err) {
        console.warn(`Failed to sync inspection ${inspection.id}:`, err);
      }
    }

    return c.json({ success: true, created, updated });
  });

  // Public verification exposes no inspection data or download links.
  app.post('/api/public/verify/:id', async (c) => {
    const { hash, kind } = await c.req.json();
    if (!/^[a-f0-9]{64}$/i.test(hash || '') || !['pdf', 'content'].includes(kind)) return c.json({ error: 'Enter a full SHA-256 hash.' }, 400);
    const records = await db.select().from(tables.reportVerifications).where(eq(tables.reportVerifications.id, c.req.param('id')));
    const record = records[0];
    const verified = !!record && (kind === 'pdf' ? record.pdfHash : record.contentHash) === hash.toLowerCase();
    return c.json({ verified, reportId: c.req.param('id'), registeredAt: verified ? record.createdAt : undefined });
  });

  app.post('/api/inspections/:id/reference/upload', async (c) => {
    const id = c.req.param('id');
    if (!await requireOwnership(auth.user!.id, id)) return c.json({ error: 'Not found' }, 404);
    const path = `references/${auth.user!.id}/${id}/${crypto.randomUUID()}.pdf`;
    const result = await storage.from(buckets.meinspect_reports).createPresignedPutUrl(path, 3600);
    return c.json({ ...result, path });
  });

  app.get('/api/inspections/:id/reference', async (c) => {
    const row = await requireOwnership(auth.user!.id, c.req.param('id'));
    if (!row) return c.json({ error: 'Not found' }, 404);
    const path = tryParse(row.extraData)?.moveInReference?.attachment?.path;
    if (typeof path !== 'string' || !path.startsWith(`references/${auth.user!.id}/${row.id}/`) || !await storage.from(buckets.meinspect_reports).head(path)) return c.json({ error: 'Reference PDF not found' }, 404);
    const { downloadUrl } = await storage.from(buckets.meinspect_reports).createPresignedGetUrl(path, 3600);
    return c.json({ downloadUrl });
  });

  // Register only after the actual PDF is present; hash its bytes on the server.
  app.post('/api/inspections/:id/finalise', async (c) => {
    const inspectionId = c.req.param('id');
    const row = await requireOwnership(auth.user!.id, inspectionId);
    if (!row) return c.json({ error: 'Not found' }, 404);
    const { contentHash, path } = await c.req.json();
    if (!/^[a-f0-9]{64}$/.test(contentHash || '')) return c.json({ error: 'Invalid content hash' }, 400);
    const reportId = `${inspectionId}-${contentHash.slice(0, 16)}`;
    if (typeof path !== 'string' || !path.startsWith(`reports/${auth.user!.id}/${inspectionId}/uploads/${reportId}-`) || !/^[a-zA-Z0-9_./-]+$/.test(path) || path.includes('..')) return c.json({ error: 'Invalid report path' }, 400);
    const file = await storage.from(buckets.meinspect_reports).get(path);
    if (!file) return c.json({ error: 'PDF upload is incomplete' }, 409);
    if (file.body.byteLength > 40 * 1024 * 1024 || !new TextDecoder().decode(file.body.slice(0, 5)).startsWith('%PDF-')) return c.json({ error: 'Invalid or oversized PDF' }, 400);
    const pdfHash = Array.from(new Uint8Array(await crypto.subtle.digest('SHA-256', file.body))).map(b => b.toString(16).padStart(2, '0')).join('');
    const existing = await db.select().from(tables.reportVerifications).where(eq(tables.reportVerifications.id, reportId));
    if (existing.length && existing[0].pdfHash !== pdfHash) return c.json({ error: 'This report version is already registered. Download the registered PDF instead.' }, 409);
    const finalPath = existing[0]?.pdfPath || `reports/${auth.user!.id}/${inspectionId}/final/${reportId}-${crypto.randomUUID()}.pdf`;
    if (!existing.length) {
      // Never issue a presigned PUT for this immutable registered-copy path.
      await storage.from(buckets.meinspect_reports).put(finalPath, file.body, { contentType: 'application/pdf' });
      await db.insert(tables.reportVerifications).values({ id: reportId, inspectionId, userId: auth.user!.id, contentHash, pdfHash, pdfPath: finalPath, createdAt: new Date().toISOString() });
    }
    await db.update(tables.inspections).set({ status: 'completed', reportGenerated: 1, pdfUrl: finalPath, completedAt: row.completedAt || new Date().toISOString() }).where(eq(tables.inspections.id, inspectionId));
    return c.json({ reportId, contentHash, pdfHash, path: finalPath });
  });

  // ==================== STORAGE ENDPOINTS (PDF & Photos) ====================

  // Get presigned upload URL for PDF report — ownership check
  app.post('/api/upload/pdf', async (c) => {
    const { inspectionId, contentHash } = await c.req.json();
    if (!inspectionId) return c.json({ error: 'inspectionId required' }, 400);

    const userId = auth.user!.id;
    const row = await requireOwnership(userId, inspectionId);
    if (!row) return c.json({ error: 'Inspection not found' }, 404);

    if (contentHash && !/^[a-f0-9]{64}$/.test(contentHash)) return c.json({ error: 'Invalid hash' }, 400);
    const reportId = contentHash ? `${inspectionId}-${contentHash.slice(0, 16)}` : '';
    if (reportId) {
      const registered = await db.select().from(tables.reportVerifications).where(eq(tables.reportVerifications.id, reportId));
      if (registered.length) {
        const { downloadUrl } = await storage.from(buckets.meinspect_reports).createPresignedGetUrl(registered[0].pdfPath, 3600);
        return c.json({ registered: true, downloadUrl, path: registered[0].pdfPath });
      }
    }
    const path = reportId ? `reports/${userId}/${inspectionId}/uploads/${reportId}-${crypto.randomUUID()}.pdf` : `reports/${userId}/${inspectionId}.pdf`;
    const { uploadUrl, expiresAt } = await storage
      .from(buckets.meinspect_reports)
      .createPresignedPutUrl(path, 3600);


    return c.json({ uploadUrl, path, expiresAt });
  });

  // Get presigned download URL for PDF report — ownership check
  app.get('/api/download/pdf/:inspectionId', async (c) => {
    const userId = auth.user!.id;
    const inspectionId = c.req.param('inspectionId');

    const row = await requireOwnership(userId, inspectionId);
    if (!row) return c.json({ error: 'Not found' }, 404);

    const path = (row as any).pdfUrl;
    if (!path) return c.json({ error: 'PDF not available for this inspection' }, 404);

    const { downloadUrl, expiresAt } = await storage
      .from(buckets.meinspect_reports)
      .createPresignedGetUrl(path, 3600);

    return c.json({ downloadUrl, expiresAt });
  });

  // Get presigned upload URL for a photo — ownership check
  app.post('/api/upload/photo', async (c) => {
    const { inspectionId, photoId, contentType, roomId = 'overall', itemId = 'cover', metadata = {} } = await c.req.json();
    if (!inspectionId || !photoId) return c.json({ error: 'inspectionId and photoId required' }, 400);

    const userId = auth.user!.id;
    const row = await requireOwnership(userId, inspectionId);
    if (!row) return c.json({ error: 'Inspection not found' }, 404);

    if (![inspectionId, photoId, roomId, itemId].every(v => typeof v === 'string' && /^[a-zA-Z0-9_-]+$/.test(v))) return c.json({ error: 'Invalid photo tags' }, 400);
    const ext = (contentType || 'image/jpeg').includes('png') ? 'png' : 'jpg';
    const path = `photos/${userId}/${inspectionId}/${roomId}/${itemId}/${photoId}.${ext}`;
    const prior = await db.select().from(tables.inspectionPhotoBackups).where(eq(tables.inspectionPhotoBackups.id, photoId));
    if (prior.length && (prior[0].userId !== userId || prior[0].inspectionId !== inspectionId)) return c.json({ error: 'Photo ID conflict' }, 409);
    if (!prior.length) await db.insert(tables.inspectionPhotoBackups).values({ id: photoId, inspectionId, userId, roomId, itemId, cloudPath: path, metadata: JSON.stringify({ id: photoId, timestamp: metadata.timestamp, gpsLat: metadata.gpsLat, gpsLng: metadata.gpsLng, caption: metadata.caption }), ready: 0 });

    const { uploadUrl, expiresAt } = await storage
      .from(buckets.meinspect_reports)
      .createPresignedPutUrl(path, 3600);

    return c.json({ uploadUrl, path, expiresAt });
  });

  // Confirm binary storage before showing a photo as backed up.
  app.post('/api/inspections/:id/photos/:photoId/confirm', async (c) => {
    const userId = auth.user!.id;
    if (!await requireOwnership(userId, c.req.param('id'))) return c.json({ error: 'Not found' }, 404);
    const rows = await db.select().from(tables.inspectionPhotoBackups).where(and(eq(tables.inspectionPhotoBackups.id, c.req.param('photoId')), eq(tables.inspectionPhotoBackups.inspectionId, c.req.param('id'))));
    const photo = rows[0];
    if (!photo || !await storage.from(buckets.meinspect_reports).head(photo.cloudPath)) return c.json({ error: 'Photo upload not complete' }, 409);
    await db.update(tables.inspectionPhotoBackups).set({ ready: 1 }).where(eq(tables.inspectionPhotoBackups.id, photo.id));
    return c.json({ success: true });
  });

  app.get('/api/inspections/:id/photos', async (c) => {
    const userId = auth.user!.id;
    const inspectionId = c.req.param('id');
    const row = await requireOwnership(userId, inspectionId);
    if (!row) return c.json({ error: 'Not found' }, 404);

    // A completed recovery copy may deliberately reference an owned source
    // inspection so an older installed app can see it as a new History item
    // without duplicating or moving any evidence objects. The alias is accepted
    // only after ownership of both rows has been verified.
    const rowExtra = tryParse(row.extraData) || {};
    const requestedSourceId = typeof rowExtra.sourceInspectionId === 'string' ? rowExtra.sourceInspectionId : '';
    const ownedSource = requestedSourceId ? await requireOwnership(userId, requestedSourceId) : null;
    const photoInspectionId = ownedSource ? requestedSourceId : inspectionId;

    const records = await db.select().from(tables.inspectionPhotoBackups).where(eq(tables.inspectionPhotoBackups.inspectionId, photoInspectionId));
    // Include older photos captured before the manifest existed, but never deleted photos.
    const referenced = new Map<string, any>();
    const collect = (list: any[], roomId: string, itemId: string) => { for (const p of list || []) referenced.set(p.id, { id: p.id, roomId, itemId, cloudPath: p.cloudPath, metadata: p }); };
    collect(tryParse(row.overallPhotos) || [], 'overall', 'cover');
    for (const [key, meter] of Object.entries(rowExtra.utilityMeters || {}) as [string, any][]) collect(meter.photo ? [meter.photo] : [], 'meters', key);
    for (const item of tryParse(row.propertyItems) || []) collect(item.photos, 'property', item.id);
    for (const room of tryParse(row.roomsData) || []) for (const item of room.items || []) collect(item.photos, room.id, item.id);
    for (const record of records) {
      if (referenced.has(record.id)) referenced.set(record.id, { ...record, metadata: tryParse(record.metadata) });
    }
    const photos = [];
    for (const photo of referenced.values()) {
      if (!photo.cloudPath || !photo.cloudPath.startsWith(`photos/${userId}/${photoInspectionId}/`) || !await storage.from(buckets.meinspect_reports).head(photo.cloudPath)) continue;
      const { downloadUrl } = await storage.from(buckets.meinspect_reports).createPresignedGetUrl(photo.cloudPath, 3600);
      photos.push({ ...photo, downloadUrl });
    }
    return c.json({ photos });
  });

  // Get presigned download URL for a photo — ownership check via path prefix
  app.get('/api/download/photo', async (c) => {
    const userId = auth.user!.id;
    const path = c.req.query('path');
    if (!path) return c.json({ error: 'path query param required' }, 400);

    // Verify the path belongs to this user
    if (!path.startsWith(`photos/${userId}/`) && !path.startsWith(`reports/${userId}/`)) {
      return c.json({ error: 'Access denied' }, 403);
    }

    const { downloadUrl, expiresAt } = await storage
      .from(buckets.meinspect_reports)
      .createPresignedGetUrl(path, 3600);

    return c.json({ downloadUrl, expiresAt });
  });

  // Batch get presigned download URLs for multiple photos — ownership check
  app.post('/api/download/photos', async (c) => {
    const userId = auth.user!.id;
    const { paths } = await c.req.json();
    if (!Array.isArray(paths)) return c.json({ error: 'paths array required' }, 400);

    const urls = await Promise.all(
      paths.map(async (path: string) => {
        try {
          // Verify each path belongs to this user
          if (!path.startsWith(`photos/${userId}/`) && !path.startsWith(`reports/${userId}/`)) {
            return { path, ok: false, error: 'Access denied' };
          }
          const { downloadUrl, expiresAt } = await storage
            .from(buckets.meinspect_reports)
            .createPresignedGetUrl(path, 3600);
          return { path, downloadUrl, expiresAt, ok: true };
        } catch {
          return { path, ok: false };
        }
      })
    );

    return c.json({ urls });
  });

  // ==================== PAYMENT ENDPOINTS ====================

  // Create checkout session
  app.post('/api/checkout', async (c) => {
    const userId = auth.user!.id;
    const { amount, currency = 'AED', inspectionId, discountCode, discountAmount } = await c.req.json();
    if (!inspectionId) return c.json({ error: 'Report ID is required' }, 400);
    const ownedInspection = await requireOwnership(userId, inspectionId);
    if (!ownedInspection) return c.json({ error: 'Report not found' }, 404);
    if (tryParse(ownedInspection.paymentData as string)?.paid === true) {
      return c.json({ success: true, status: 'paid', alreadyPaid: true });
    }

    // Check if user is a tester
    const userRows = await db.select().from(tables.users).where(eq(tables.users.id, userId));
    const isTester = userRows.length > 0 && userRows[0].isTester === 1;
    const freeCredits = userRows.length > 0 ? (userRows[0].freeInspections ?? 0) : 0;

    if (isTester) {
      const sessionId = `tester_${Date.now()}_${Math.random().toString(36).slice(2)}`;
      const paidAt = Math.floor(Date.now() / 1000);
      const order = await db.insert(tables.orders).values({
        environment: getEnv(),
        userId,
        inspectionId: inspectionId || null,
        amount: amount || 0,
        currency,
        status: 'paid',
        paidAt,
        type: 'one_time',
        provider: 'tester',
        providerSessionId: sessionId,
        discountCode: 'TESTER_PROVISION',
        discountAmount: amount || 0,
      }).returning();
      await db.update(tables.inspections)
        .set({ paymentData: JSON.stringify({ paid: true, sessionId, provider: 'tester', amount: amount || 0, currency, paidAt }) })
        .where(eq(tables.inspections.id, inspectionId));

      return c.json({
        success: true,
        sessionId,
        orderId: order[0].id,
        status: 'paid',
        message: 'Tester payment processed successfully (Free)',
      });
    }

    // Real Stripe Integration
    const stripeKey = getStripeKey();
    const priceId = secret.get('STRIPE_PRICE_ID');

    if (!stripeKey || !priceId) {
      return c.json({ error: 'Payment service is unavailable' }, 500);
    }

    const stripe = new Stripe(stripeKey, { apiVersion: '2023-10-16' as any });

    // Reuse an existing open Checkout session for this exact report instead of
    // creating duplicate payment attempts. Stripe remains authoritative for the
    // session's current status and URL.
    const existingOrders = await db.select().from(tables.orders)
      .where(and(
        eq(tables.orders.environment, getEnv()),
        eq(tables.orders.userId, userId),
        eq(tables.orders.inspectionId, inspectionId),
        eq(tables.orders.provider, 'stripe'),
        eq(tables.orders.status, 'pending')
      ));
    for (const existingOrder of existingOrders.sort((a: any, b: any) => (b.createdAt || 0) - (a.createdAt || 0))) {
      if (!existingOrder.providerSessionId) continue;
      try {
        const existingSession = await stripe.checkout.sessions.retrieve(existingOrder.providerSessionId);
        if (existingSession.status === 'open' && existingSession.url) {
          console.log(`[CHECKOUT] action=reused report=${inspectionId} session=${existingSession.id}`);
          return c.json({
            success: true,
            sessionId: existingSession.id,
            url: existingSession.url,
            orderId: existingOrder.id,
            status: 'pending',
            reused: true,
            stripeRequestId: existingSession.lastResponse?.requestId,
          });
        }
      } catch (error) {
        console.warn(`[CHECKOUT] open-session lookup failed report=${inspectionId} session=${existingOrder.providerSessionId}`);
      }
    }

    // ---- FREE CREDITS CHECK ----
    // If the user has admin-granted free inspection credits, use one now
    // before charging Stripe.
    if (freeCredits > 0) {
      const sessionId = `credit_${Date.now()}_${Math.random().toString(36).slice(2)}`;
      // D1 batches are atomic: debit, order and unlock commit together, or all
      // roll back. The conditional debit is the sole credit-consumption authority.
      // changes() in the immediately following INSERT refers to that debit,
      // not an earlier SELECT or a value read into application memory.
      const [debited, order, unlocked] = await db.batch([
        db.update(tables.users)
          .set({ freeInspections: sql`${tables.users.freeInspections} - 1` })
          .where(and(
            eq(tables.users.id, userId),
            sql`${tables.users.freeInspections} > 0`,
            sql`EXISTS (SELECT 1 FROM ${tables.inspections}
              WHERE ${tables.inspections.id} = ${inspectionId}
              AND ${tables.inspections.userId} = ${userId}
              AND COALESCE(json_extract(CASE WHEN json_valid(${tables.inspections.paymentData}) THEN ${tables.inspections.paymentData} ELSE '{}' END, '$.paid'), 0) NOT IN (1, 'true'))`,
            sql`NOT EXISTS (SELECT 1 FROM ${tables.orders}
              WHERE ${tables.orders.inspectionId} = ${inspectionId} AND ${tables.orders.status} = 'paid')`
          )).returning({ balance: tables.users.freeInspections }),
        db.insert(tables.orders).select(sql`SELECT NULL, ${getEnv()}, ${userId}, ${inspectionId}, NULL,
          0, ${currency}, 'paid', 'one_time', 'admin_credit', ${sessionId}, NULL,
          'ADMIN_CREDIT', ${amount || 199}, NULL, ${Math.floor(Date.now() / 1000)}, ${Math.floor(Date.now() / 1000)}
          WHERE changes() = 1`).returning(),
        db.update(tables.inspections)
          .set({ paymentData: JSON.stringify({ paid: true, sessionId, provider: 'admin_credit' }) })
          .where(and(
            eq(tables.inspections.id, inspectionId),
            eq(tables.inspections.userId, userId),
            sql`EXISTS (SELECT 1 FROM ${tables.orders} WHERE ${tables.orders.providerSessionId} = ${sessionId}
              AND ${tables.orders.inspectionId} = ${inspectionId} AND ${tables.orders.userId} = ${userId})`
          )).returning({ id: tables.inspections.id }),
      ]);
      if (debited.length !== 1) {
        const latest = await requireOwnership(userId, inspectionId);
        if (tryParse(latest?.paymentData)?.paid === true) {
          return c.json({ success: true, status: 'paid', alreadyPaid: true });
        }
        return c.json({ error: 'No credit was used. Your credit balance or report access changed; refresh and try again.' }, 409);
      }
      if (order.length !== 1 || unlocked.length !== 1) {
        throw new Error('Credit payment could not be confirmed');
      }
      console.log(`[CHECKOUT] Used 1 admin credit for user ${userId}. Remaining: ${debited[0].balance}`);

      return c.json({
        success: true,
        sessionId,
        orderId: order[0].id,
        status: 'paid',
        message: 'Free inspection credit used successfully.',
      });
    }
    // ---- END FREE CREDITS CHECK ----

    // Validate discount and calculate final amount
    const BASE_PRICE = 199;
    const VALID_DISCOUNT_CODES: Record<string, { type: 'percent' | 'fixed'; value: number }> = {
      'WELCOME20': { type: 'percent', value: 20 },
      'LAUNCH50': { type: 'fixed', value: 50 },
      'MEINSPECT10': { type: 'percent', value: 10 },
      'INSPECTOR': { type: 'fixed', value: 100 },
      'FREE_REPORT': { type: 'percent', value: 100 },
    };

    let finalAmount = BASE_PRICE;
    if (discountCode) {
      const offer = VALID_DISCOUNT_CODES[discountCode.toUpperCase()];
      if (offer) {
        const discount = offer.type === 'percent' ? Math.round(BASE_PRICE * offer.value / 100) : offer.value;
        finalAmount = Math.max(0, BASE_PRICE - discount);
      }
    }

    // If final amount is 0, process as free report
    if (finalAmount === 0) {
      const sessionId = `free_${Date.now()}_${Math.random().toString(36).slice(2)}`;
      const paidAt = Math.floor(Date.now() / 1000);
      const order = await db.insert(tables.orders).values({
        environment: getEnv(),
        userId,
        inspectionId: inspectionId || null,
        amount: 0,
        currency,
        status: 'paid',
        paidAt,
        type: 'one_time',
        provider: 'discount',
        providerSessionId: sessionId,
        discountCode: discountCode || 'FREE_PROMO',
        discountAmount: BASE_PRICE,
      }).returning();
      const freePaymentData = { paid: true, sessionId, provider: 'discount', amount: 0, currency, paidAt };
      await db.update(tables.inspections)
        .set({ paymentData: JSON.stringify(freePaymentData) })
        .where(eq(tables.inspections.id, inspectionId));

      const user = userRows[0];
      if (user?.email) {
        const emailResult = await sendNotificationEmail(
          user.email,
          `Your report is unlocked (RPT-${inspectionId.slice(0, 8).toUpperCase()})`,
          `<div style="font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',Roboto,sans-serif;max-width:600px;margin:0 auto;padding:32px"><h1 style="color:#1e293b">Your report is unlocked</h1><p>Hi ${user.name || 'there'},</p><p>Your report is ready to access.</p><p><strong>Report ID:</strong> RPT-${inspectionId.slice(0, 8).toUpperCase()}</p><p><a href="${reportAccessUrl(inspectionId)}" style="display:inline-block;background:#2563eb;color:#fff;padding:12px 24px;border-radius:8px;text-decoration:none;font-weight:600">Access Your Report</a></p></div>`
        );
        if (emailResult.ok) {
          await db.update(tables.inspections)
            .set({ paymentData: JSON.stringify({ ...freePaymentData, confirmationEmailSentAt: paidAt }) })
            .where(eq(tables.inspections.id, inspectionId));
        } else {
          console.error(`[CHECKOUT] free report unlock email failed report=${inspectionId}: ${emailResult.error || 'unknown error'}`);
        }
      }

      return c.json({
        success: true,
        sessionId,
        orderId: order[0].id,
        status: 'paid',
        message: 'Free report processed successfully',
      });
    }

    try {
      const session = await stripe.checkout.sessions.create({
        payment_method_types: ['card'],
        line_items: [
          {
            price_data: {
              currency: currency.toLowerCase(),
              product_data: {
                name: 'Property Inspection Report',
                description: discountCode ? `Discount applied: ${discountCode}` : undefined,
              },
              unit_amount: finalAmount * 100, // Stripe expects cents
            },
            quantity: 1,
          },
        ],
        mode: 'payment',
        invoice_creation: {
          enabled: true,
        },
        // Promotion codes are supported for this one-time payment flow.
        allow_promotion_codes: getEnv() === 'production',
        success_url: `${reportAccessUrl(inspectionId)}?payment=success&session_id={CHECKOUT_SESSION_ID}`,
        cancel_url: `${reportAccessUrl(inspectionId)}?payment=cancel`,
        metadata: {
          userId,
          inspectionId: inspectionId || '',
          reportId: inspectionId || '', // Explicitly adding reportId as requested
        },
      });

      // Record the order
      const order = await db.insert(tables.orders).values({
        environment: getEnv(),
        userId,
        inspectionId: inspectionId || null,
        amount: finalAmount,
        currency,
        status: 'pending',
        type: 'one_time',
        provider: 'stripe',
        providerSessionId: session.id,
        discountCode: discountCode || null,
        discountAmount: BASE_PRICE - finalAmount,
      }).returning();

      return c.json({
        success: true,
        sessionId: session.id,
        url: session.url,
        orderId: order[0].id,
        status: 'pending',
        stripeRequestId: session.lastResponse?.requestId,
      });
    } catch (err: any) {
      const requestId = err?.requestId || err?.raw?.requestId || null;
      console.error(`[CHECKOUT] Stripe rejected request report=${inspectionId} requestId=${requestId || 'unavailable'} type=${err?.type || 'unknown'}`);
      if (requestId) c.header('Stripe-Request-Id', requestId);
      return c.json({ error: "We couldn't start the payment. Please try again", retryable: true }, 502);
    }
  });

  // Expire an owned open Checkout session. This is used by the required QA
  // smoke test so its live-mode verification session can never be paid.
  app.post('/api/checkout/:sessionId/expire', async (c) => {
    const userId = auth.user!.id;
    const sessionId = c.req.param('sessionId');
    const orderRows = await db.select().from(tables.orders)
      .where(and(
        eq(tables.orders.providerSessionId, sessionId),
        eq(tables.orders.userId, userId),
        eq(tables.orders.provider, 'stripe')
      ));
    const order = orderRows[0];
    if (!order) return c.json({ error: 'Session not found' }, 404);

    const stripeKey = getStripeKey();
    if (!stripeKey) return c.json({ error: 'Payment service is unavailable' }, 500);
    try {
      const stripe = new Stripe(stripeKey, { apiVersion: '2023-10-16' as any });
      const session = await stripe.checkout.sessions.expire(sessionId);
      return c.json({
        success: true,
        sessionId: session.id,
        status: session.status,
        stripeRequestId: session.lastResponse?.requestId,
      });
    } catch (err: any) {
      const requestId = err?.requestId || err?.raw?.requestId || null;
      console.error(`[CHECKOUT] expire failed session=${sessionId} requestId=${requestId || 'unavailable'}`);
      if (requestId) c.header('Stripe-Request-Id', requestId);
      return c.json({ error: 'We could not expire the payment session' }, 502);
    }
  });

  // Verify a Checkout session directly with Stripe and reconcile the server state.
  app.get('/api/checkout/:sessionId', async (c) => {
    const userId = auth.user!.id;
    const sessionId = c.req.param('sessionId');
    const orderRows = await db.select().from(tables.orders)
      .where(and(
        eq(tables.orders.providerSessionId, sessionId),
        eq(tables.orders.userId, userId)
      ));
    const order = orderRows[0];
    if (!order) return c.json({ error: 'Session not found' }, 404);

    if (order.provider === 'stripe') {
      const stripeKey = getStripeKey();
      if (!stripeKey) return c.json({ error: 'Stripe not configured' }, 500);
      const stripe = new Stripe(stripeKey, { apiVersion: '2023-10-16' as any });
      try {
        const session = await stripe.checkout.sessions.retrieve(sessionId);
        await confirmStripeCheckout(session, 'session_reconcile');
      } catch (err) {
        console.error(`[PAYMENT_RECONCILE] session=${sessionId} failed:`, err);
        return c.json({ error: 'Payment confirmation failed. Please retry.' }, 502);
      }
    }

    const refreshed = await db.select().from(tables.orders)
      .where(eq(tables.orders.id, order.id));
    return c.json({ data: refreshed[0] });
  });

  // Re-check the newest payment for a report. This powers "I already paid" and
  // recovery after the app was closed without requiring the return URL.
  app.post('/api/inspections/:id/reconcile-payment', async (c) => {
    const userId = auth.user!.id;
    const reportId = c.req.param('id');
    const report = await requireOwnership(userId, reportId);
    if (!report) return c.json({ error: 'Report not found' }, 404);
    if (tryParse(report.paymentData as string)?.paid === true) {
      return c.json({ paid: true, reportId, sessionId: tryParse(report.paymentData as string)?.sessionId });
    }

    const orders = await db.select().from(tables.orders)
      .where(and(
        eq(tables.orders.inspectionId, reportId),
        eq(tables.orders.userId, userId)
      ));
    const stripeOrder = orders
      .filter((item: any) => item.provider === 'stripe' && item.providerSessionId)
      .sort((a: any, b: any) => (b.createdAt || 0) - (a.createdAt || 0))[0];
    if (!stripeOrder) return c.json({ paid: false, reportId });

    const stripeKey = getStripeKey();
    if (!stripeKey) return c.json({ error: 'Stripe not configured' }, 500);
    try {
      const stripe = new Stripe(stripeKey, { apiVersion: '2023-10-16' as any });
      const session = await stripe.checkout.sessions.retrieve(stripeOrder.providerSessionId!);
      const result = await confirmStripeCheckout(session, 'report_reconcile');
      return c.json({ paid: result.paid, reportId, sessionId: session.id });
    } catch (err) {
      console.error(`[PAYMENT_RECONCILE] report=${reportId} failed:`, err);
      return c.json({ error: 'Payment confirmation failed. Please retry.' }, 502);
    }
  });

  // The Stripe return can land in a browser without the app's login session.
  // The unguessable Checkout session id is used only to confirm payment and
  // return routing information; no report data is exposed.
  app.post('/api/public/payments/confirm', async (c) => {
    const { sessionId, reportId } = await c.req.json().catch(() => ({}));
    if (!sessionId || !reportId) return c.json({ error: 'sessionId and reportId are required' }, 400);
    const stripeKey = getStripeKey();
    if (!stripeKey) return c.json({ error: 'Stripe not configured' }, 500);
    try {
      const stripe = new Stripe(stripeKey, { apiVersion: '2023-10-16' as any });
      const session = await stripe.checkout.sessions.retrieve(String(sessionId));
      const metadataReportId = session.metadata?.reportId || session.metadata?.inspectionId;
      if (metadataReportId !== String(reportId)) return c.json({ error: 'Payment does not match report' }, 403);
      const result = await confirmStripeCheckout(session, 'session_reconcile');
      return c.json({ paid: result.paid, reportId: result.reportId });
    } catch (err) {
      console.error(`[PAYMENT_PUBLIC_CONFIRM] session=${sessionId} report=${reportId} failed:`, err);
      return c.json({ error: 'Payment confirmation failed. Please retry.' }, 502);
    }
  });

  // Browser/WebView launch failures contain device/runtime details only. Do not
  // accept email, report content, tokens, or other customer data here.
  app.post('/api/public/payments/client-error', async (c) => {
    const body = await c.req.json().catch(() => ({}));
    const safe = {
      stage: String(body.stage || '').slice(0, 40),
      error: String(body.error || '').slice(0, 300),
      platform: String(body.platform || '').slice(0, 40),
      deviceModel: String(body.deviceModel || '').slice(0, 100),
      androidVersion: String(body.androidVersion || '').slice(0, 40),
      webViewOrChromeVersion: String(body.webViewOrChromeVersion || '').slice(0, 40),
    };
    console.error('[PAYMENT_CLIENT_ERROR]', safe);
    return c.json({ received: true });
  });

  // Read-only companion for scripts/audit-stripe-unlocks.mjs. It compares a
  // caller-supplied list of successful Stripe sessions with authoritative
  // report payment state; it never updates or refunds anything.
  app.post('/api/admin/audit-stripe-unlocks', async (c) => {
    if (!await requireAdmin()) return c.json({ error: 'Admin access required' }, 403);
    const { payments } = await c.req.json().catch(() => ({ payments: [] }));
    if (!Array.isArray(payments) || payments.length > 1000) return c.json({ error: 'payments array required' }, 400);

    const lockedSuccessfulPayments: any[] = [];
    for (const payment of payments) {
      const reportId = typeof payment?.reportId === 'string' ? payment.reportId : '';
      if (!reportId) continue;
      const rows = await db.select().from(tables.inspections).where(eq(tables.inspections.id, reportId));
      const report = rows[0];
      if (!report || tryParse(report.paymentData as string)?.paid !== true) {
        lockedSuccessfulPayments.push({
          reportId,
          sessionId: String(payment.sessionId || ''),
          amount: Number(payment.amount || 0),
          currency: String(payment.currency || ''),
          created: Number(payment.created || 0),
          reportFound: !!report,
          reportStatus: report?.status || null,
        });
      }
    }
    return c.json({ lockedSuccessfulPayments });
  });

  // ==================== STRIPE WEBHOOK ====================

  app.post('/api/webhooks/stripe', async (c) => {
    const signature = c.req.header('stripe-signature') || '';
    const signingSecret = secret.get(stripeWebhookSecretName());
    
    if (!signingSecret) {
      console.error('[WEBHOOK] signing secret is not configured');
      return c.json({ error: 'Webhook not configured' }, 500);
    }

    const stripeKey = getStripeKey();
    if (!stripeKey) {
      console.error('[WEBHOOK] STRIPE_SECRET_KEY not configured');
      return c.json({ error: 'Stripe not configured' }, 500);
    }

    const stripe = new Stripe(stripeKey, { apiVersion: '2023-10-16' as any });

    const body = await c.req.text();
    let event: Stripe.Event;
    let eventSource: 'webhook' | 'webhook_fallback' = 'webhook';
    try {
      event = await stripe.webhooks.constructEventAsync(body, signature, signingSecret);
    } catch (err: any) {
      let claimedEventId = '';
      try {
        const parsed = JSON.parse(body);
        if (typeof parsed?.id === 'string' && /^evt_[A-Za-z0-9]+$/.test(parsed.id)) claimedEventId = parsed.id;
      } catch {}
      if (!claimedEventId) {
        console.error('[WEBHOOK] signature verification failed and no valid event id was supplied');
        return c.json({ error: 'Invalid Stripe signature' }, 400);
      }

      console.warn(`[WEBHOOK_FALLBACK] signature verification failed; retrieving event=${claimedEventId} from Stripe`);
      try {
        event = await stripe.events.retrieve(claimedEventId);
        eventSource = 'webhook_fallback';
        console.warn(`[WEBHOOK_FALLBACK] retrieved event=${event.id} type=${event.type}`);
      } catch (retrieveError: any) {
        console.error(`[WEBHOOK_FALLBACK] Stripe retrieval failed event=${claimedEventId} requestId=${retrieveError?.requestId || 'unavailable'}`);
        return c.json({ error: 'Invalid Stripe event' }, 400);
      }
    }

    try {
      console.log(`[WEBHOOK] Received event: ${event.type}`);
      if (event.type === 'checkout.session.completed' || event.type === 'checkout.session.async_payment_succeeded') {
        const session = event.data.object as Stripe.Checkout.Session;
        await confirmStripeCheckout(session, eventSource);
      }

      // Stripe receives 2xx only after every required database write above has
      // completed. Any processing failure returns 500 so Stripe retries.
      return c.json({ received: true });
    } catch (err: any) {
      console.error('[WEBHOOK] processing error:', err);
      return c.json({ error: `Webhook processing failed: ${err.message}` }, 500);
    }
  });

  // ==================== REVENUECAT WEBHOOK (iOS IAP) ====================
  // Security-critical: this is the ONLY place in the entire codebase that may
  // unlock report access for the com.meinspect.app.report in-app purchase.
  // The client's purchase success callback is NEVER trusted on its own — it
  // only shows a "confirming" state and polls GET /api/inspections/:id until
  // this webhook (verified below) has flipped paymentData.paid to true.
  //
  // Correlation model: the iOS client calls Purchases.logIn(inspectionId)
  // before showing the purchase button, so RevenueCat's app_user_id for this
  // purchase IS the inspection's id — mirroring the existing Stripe flow,
  // where metadata.inspectionId ties a checkout session to one report.
  app.post('/api/webhooks/revenuecat', async (c) => {
    // ---- Fail-closed secret verification. No fallback value, ever. ----
    const expectedSecret = secret.get('REVENUECAT_WEBHOOK_SECRET');
    if (!expectedSecret) {
      console.error('[REVENUECAT_WEBHOOK] REVENUECAT_WEBHOOK_SECRET not configured — rejecting all requests');
      return c.json({ error: 'Webhook not configured' }, 500);
    }
    const authHeader = c.req.header('Authorization');
    if (!authHeader || authHeader !== `Bearer ${expectedSecret}`) {
      console.warn('[REVENUECAT_WEBHOOK] Unauthorized request — missing/invalid Authorization header');
      return c.json({ error: 'Unauthorized' }, 401);
    }

    // ---- Parse RevenueCat event payload ----
    let body: any;
    try {
      body = await c.req.json();
    } catch (err) {
      console.error('[REVENUECAT_WEBHOOK] Invalid JSON body:', err);
      return c.json({ error: 'Invalid JSON body' }, 400);
    }

    const event = body?.event;
    if (!event || typeof event !== 'object') {
      console.warn('[REVENUECAT_WEBHOOK] Missing event object in payload');
      return c.json({ error: 'Missing event' }, 400);
    }

    const eventType: string = event.type;
    const productId: string = event.product_id;
    // The client sets RevenueCat's appUserID = inspectionId via Purchases.logIn()
    // before purchasing, so app_user_id IS the report's inspection id.
    const inspectionId: string | undefined = event.app_user_id;
    const transactionId: string | undefined = event.transaction_id || event.original_transaction_id;
    const eventId: string | undefined = event.id;

    // --- Structured, always-on diagnostics (step 4 of the debugging brief). ---
    // Every RevenueCat webhook now logs, in one place: the exact app_user_id
    // received, whether a matching inspection row was found, and what action
    // was ultimately taken (unlocked / revoked / no-match / ignored / error).
    // Previously a silent "no action" path made failures invisible.
    console.log(`[REVENUECAT_WEBHOOK] Received event: type=${eventType} product=${productId} app_user_id=${inspectionId} transaction=${transactionId} event_id=${eventId}`);

    const REPORT_PRODUCT_ID = 'com.meinspect.app.report';
    if (productId !== REPORT_PRODUCT_ID) {
      // Not our product — acknowledge without action (forward-compatible with
      // any other products configured in RevenueCat in the future).
      console.log(`[REVENUECAT_WEBHOOK] action=ignored reason=unrelated_product product=${productId} app_user_id=${inspectionId}`);
      return c.json({ received: true });
    }

    if (!inspectionId) {
      console.warn(`[REVENUECAT_WEBHOOK] action=ignored reason=missing_app_user_id event_id=${eventId}`);
      return c.json({ received: true });
    }

    const inspectionRows = await db.select().from(tables.inspections)
      .where(eq(tables.inspections.id, inspectionId));

    const matchFound = inspectionRows.length > 0;
    console.log(`[REVENUECAT_WEBHOOK] app_user_id=${inspectionId} match_found=${matchFound} event_type=${eventType}`);

    if (!matchFound) {
      console.warn(`[REVENUECAT_WEBHOOK] action=no_match reason=no_inspection_row app_user_id=${inspectionId} — returning 200 (event may be unrelated or the row does not exist yet)`);
      return c.json({ received: true });
    }

    const currentData = tryParse(inspectionRows[0].paymentData as string);

    // ---- Event-type classification (ROOT-CAUSE FIX) ----
    // The report unlock (`com.meinspect.app.report`) is a NON-subscription,
    // one-time purchase. RevenueCat fires `NON_RENEWING_PURCHASE` for these,
    // NOT `INITIAL_PURCHASE` (which is only sent for subscriptions). The old
    // handler only granted on `INITIAL_PURCHASE`, so a genuine, verified
    // one-time purchase fell through to the silent "no action" branch,
    // returned 200, and left the report locked forever. We now treat every
    // grant-type event as an unlock.
    const GRANT_EVENTS = new Set([
      'INITIAL_PURCHASE',       // subscriptions (kept for completeness)
      'NON_RENEWING_PURCHASE',  // one-time / consumable purchases — OUR product
      'RENEWAL',                // subscription renewals (kept for completeness)
      'UNCANCELLATION',         // user reversed a pending cancellation
      'PRODUCT_CHANGE',         // upgrade/crossgrade still implies active access
    ]);
    const REVOKE_EVENTS = new Set([
      'CANCELLATION',
      'REFUND',
      'EXPIRATION',
    ]);

    if (GRANT_EVENTS.has(eventType)) {
      await db.update(tables.inspections)
        .set({
          paymentData: JSON.stringify({
            ...currentData,
            paid: true,
            provider: 'revenuecat',
            productId,
            transactionId,
            paidAt: Math.floor(Date.now() / 1000),
            unlockedByEvent: eventType,
          }),
        })
        .where(eq(tables.inspections.id, inspectionId));
      console.log(`[REVENUECAT_WEBHOOK] action=unlocked app_user_id=${inspectionId} event_type=${eventType} transaction=${transactionId}`);
    } else if (REVOKE_EVENTS.has(eventType)) {
      await db.update(tables.inspections)
        .set({
          paymentData: JSON.stringify({
            ...currentData,
            paid: false,
            provider: 'revenuecat',
            productId,
            transactionId,
            revokedAt: Math.floor(Date.now() / 1000),
            revokedReason: eventType,
          }),
        })
        .where(eq(tables.inspections.id, inspectionId));
      console.warn(`[REVENUECAT_WEBHOOK] action=revoked app_user_id=${inspectionId} event_type=${eventType} transaction=${transactionId}`);
    } else {
      // Genuinely informational events (TEST, BILLING_ISSUE, TRANSFER, etc.).
      console.log(`[REVENUECAT_WEBHOOK] action=no_op reason=non_actionable_event event_type=${eventType} app_user_id=${inspectionId}`);
    }

    return c.json({ received: true });
  });

  // ==================== REVENUECAT RECONCILIATION (SAFETY NET) ====================
  // Manual reconciliation path for the iOS in-app purchase. If the webhook is
  // delayed or was missed entirely, the client can call this after its
  // "Confirming Purchase" poll times out. Instead of relying solely on the
  // webhook having already run, we query RevenueCat's OWN record of this
  // customer's (app_user_id === inspectionId) purchase history via the REST
  // API. If RevenueCat confirms a valid, non-refunded purchase of our product,
  // we unlock the report directly here — so a user is never permanently stuck.
  //
  // Trust model preserved: unlocking still requires an authoritative,
  // server-side confirmation from RevenueCat (not the client's word), and this
  // endpoint enforces that the caller owns the inspection.
  app.post('/api/inspections/:id/reconcile-purchase', async (c) => {
    const userId = auth.user?.id;
    if (!userId) {
      return c.json({ error: 'Unauthorized' }, 401);
    }
    const inspectionId = c.req.param('id');

    // Ownership check — a user can only reconcile their own report.
    const rows = await db.select().from(tables.inspections)
      .where(and(eq(tables.inspections.id, inspectionId), eq(tables.inspections.userId, userId)));
    if (rows.length === 0) {
      console.warn(`[REVENUECAT_RECONCILE] app_user_id=${inspectionId} user=${userId} action=denied reason=not_owner_or_missing`);
      return c.json({ error: 'Inspection not found' }, 404);
    }

    const currentData = tryParse(rows[0].paymentData as string);
    if (currentData?.paid === true) {
      // Already unlocked (webhook may have won the race) — nothing to do.
      console.log(`[REVENUECAT_RECONCILE] app_user_id=${inspectionId} action=already_paid`);
      return c.json({ paid: true, source: 'already_paid' });
    }

    const apiKey = secret.get('REVENUECAT_SECRET_API_KEY');
    if (!apiKey) {
      console.error('[REVENUECAT_RECONCILE] REVENUECAT_SECRET_API_KEY not configured — cannot reconcile');
      return c.json({ paid: false, error: 'Reconciliation not configured' }, 500);
    }

    // Query RevenueCat's authoritative record for this app_user_id.
    let subscriber: any = null;
    try {
      const rcRes = await fetch(
        `https://api.revenuecat.com/v1/subscribers/${encodeURIComponent(inspectionId)}`,
        { headers: { Authorization: `Bearer ${apiKey}`, 'Content-Type': 'application/json' } }
      );
      if (!rcRes.ok) {
        const body = await rcRes.text().catch(() => '');
        console.warn(`[REVENUECAT_RECONCILE] app_user_id=${inspectionId} action=rc_lookup_failed status=${rcRes.status} body=${body.slice(0, 200)}`);
        return c.json({ paid: false, source: 'revenuecat', error: 'RevenueCat lookup failed' });
      }
      const data = await rcRes.json() as any;
      subscriber = data?.subscriber;
    } catch (err) {
      console.error(`[REVENUECAT_RECONCILE] app_user_id=${inspectionId} action=rc_lookup_error`, err);
      return c.json({ paid: false, source: 'revenuecat', error: 'RevenueCat unreachable' });
    }

    const REPORT_PRODUCT_ID = 'com.meinspect.app.report';

    // A valid one-time purchase shows up under `non_subscriptions[productId]`,
    // an array of transactions. A refunded transaction carries `is_refunded`.
    const nonSubs = subscriber?.non_subscriptions?.[REPORT_PRODUCT_ID];
    const validNonSub = Array.isArray(nonSubs)
      ? nonSubs.find((t: any) => t && t.is_refunded !== true)
      : null;

    // Some configurations grant an entitlement instead — accept an active
    // (non-expired) entitlement tied to this product as confirmation too.
    const entitlements = subscriber?.entitlements || {};
    const now = Date.now();
    const activeEntitlement = Object.values(entitlements).find((e: any) => {
      if (!e) return false;
      const notExpired = !e.expires_date || new Date(e.expires_date).getTime() > now;
      const matchesProduct = !e.product_identifier || e.product_identifier === REPORT_PRODUCT_ID;
      return notExpired && matchesProduct;
    });

    if (validNonSub || activeEntitlement) {
      const purchaseDate = (validNonSub && validNonSub.purchase_date) || null;
      const txnId = (validNonSub && (validNonSub.store_transaction_id || validNonSub.id)) || 'reconciled';
      await db.update(tables.inspections)
        .set({
          paymentData: JSON.stringify({
            ...currentData,
            paid: true,
            provider: 'revenuecat',
            productId: REPORT_PRODUCT_ID,
            transactionId: txnId,
            paidAt: Math.floor(Date.now() / 1000),
            unlockedByEvent: 'RECONCILIATION',
            reconciledPurchaseDate: purchaseDate,
          }),
        })
        .where(eq(tables.inspections.id, inspectionId));
      console.log(`[REVENUECAT_RECONCILE] app_user_id=${inspectionId} action=unlocked source=revenuecat transaction=${txnId}`);
      return c.json({ paid: true, source: 'revenuecat' });
    }

    console.log(`[REVENUECAT_RECONCILE] app_user_id=${inspectionId} action=no_purchase_found source=revenuecat`);
    return c.json({ paid: false, source: 'revenuecat' });
  });

  // Get user's payment history
  app.get('/api/orders', async (c) => {
    const userId = auth.user!.id;
    const orders = await db.select().from(tables.orders)
      .where(eq(tables.orders.userId, userId));
    return c.json({ data: orders });
  });

  // Get invoice URL for an order
  app.get('/api/orders/:id/invoice', async (c) => {
    const userId = auth.user!.id;
    const orderId = parseInt(c.req.param('id'));
    
    const result = await db.select().from(tables.orders)
      .where(
        and(
          eq(tables.orders.id, orderId),
          eq(tables.orders.userId, userId)
        )
      );
      
    if (result.length === 0) return c.json({ error: 'Order not found' }, 404);
    const order = result[0];
    
    if (order.provider !== 'stripe' || !order.providerSessionId) {
      return c.json({ error: 'Invoice not available for this order' }, 400);
    }
    
    const stripeKey = getStripeKey();
    if (!stripeKey) return c.json({ error: 'Stripe not configured' }, 500);
    
    const stripe = new Stripe(stripeKey, { apiVersion: '2023-10-16' as any });
    
    try {
      // Retrieve the session to get the invoice ID
      const session = await stripe.checkout.sessions.retrieve(order.providerSessionId, {
        expand: ['invoice'],
      });
      
      const invoice = session.invoice as Stripe.Invoice;
      if (!invoice || !invoice.hosted_invoice_url) {
        return c.json({ error: 'Invoice not yet generated' }, 404);
      }
      
      return c.json({ url: invoice.hosted_invoice_url });
    } catch (err: any) {
      console.error('[STRIPE] invoice error:', err);
      return c.json({ error: err.message }, 500);
    }
  });

  // ==================== ADMIN ENDPOINTS ====================
  // All admin endpoints require admin privileges

  const adminUserIds = (): Set<string> => new Set(
    (secret.get('ADMIN_USER_IDS') || '')
      .split(',')
      .map(id => id.trim())
      .filter(Boolean)
  );

  const requireAdmin = async (): Promise<boolean> => {
    const userId = auth.user?.id;
    if (!userId) return false;
    if (adminUserIds().has(userId)) return true;
    const rows = await db.select({ isAdmin: tables.users.isAdmin }).from(tables.users)
      .where(eq(tables.users.id, userId)).limit(1);
    return rows[0]?.isAdmin === 1;
  };

  app.get('/api/admin/access', async (c) => {
    if (!await requireAdmin()) return c.json({ error: 'Admin access required' }, 403);
    return c.json({ isAdmin: true });
  });

  // Create payment price
  app.post('/api/admin/prices', async (c) => {
    if (!await requireAdmin()) return c.json({ error: 'Admin access required' }, 403);
    
    const { name, amount, currency = 'AED', type = 'one_time' } = await c.req.json();
    const env = getEnv();

    const row = await db.insert(tables.paymentPrices).values({
      environment: env,
      name,
      amount,
      currency,
      type,
      provider: 'stripe',
    }).returning();

    return c.json({ data: row[0] }, 201);
  });

  // List payment prices
  app.get('/api/admin/prices', async (c) => {
    if (!await requireAdmin()) return c.json({ error: 'Admin access required' }, 403);
    
    const env = getEnv();
    const prices = await db.select().from(tables.paymentPrices)
      .where(eq(tables.paymentPrices.environment, env));
    return c.json({ data: prices });
  });

  // Set user as tester
  app.post('/api/admin/set-tester', async (c) => {
    if (!await requireAdmin()) return c.json({ error: 'Admin access required' }, 403);
    
    const { email, isTester } = await c.req.json();
    await db.update(tables.users)
      .set({ isTester: isTester ? 1 : 0 })
      .where(eq(tables.users.email, email));
    return c.json({ success: true, message: `User ${email} tester status set to ${isTester}` });
  });

  // ==================== ADMIN CREDIT ENDPOINTS ====================
  // Admin access is session-based: ADMIN_USER_IDS or the existing is_admin flag.

  // GET /api/admin/users — list all users with their free inspection credits
  app.get('/api/admin/users', async (c) => {
    if (!await requireAdmin()) return c.json({ error: 'Admin access required' }, 403);
    const q = c.req.query('q') || '';
    let rows;
    if (q) {
      // Simple case-insensitive filter; SQLite LIKE is case-insensitive for ASCII
      rows = await db.select().from(tables.users);
      rows = rows.filter((u: any) =>
        u.email?.toLowerCase().includes(q.toLowerCase()) ||
        u.name?.toLowerCase().includes(q.toLowerCase())
      );
    } else {
      rows = await db.select().from(tables.users);
    }
    // Count total inspections per user
    const enriched = await Promise.all(rows.map(async (u: any) => {
      const inspectionCount = await db.select().from(tables.inspections)
        .where(eq(tables.inspections.userId, u.id));
      return {
        id: u.id,
        email: u.email,
        name: u.name,
        phone: u.phone,
        location: u.location,
        isTester: u.isTester,
        freeInspections: u.freeInspections ?? 0,
        totalInspections: inspectionCount.length,
        createdAt: u.createdAt,
      };
    }));
    return c.json({ data: enriched });
  });

  // POST /api/admin/grant-credits — grant N free inspection credits to a user
  app.post('/api/admin/grant-credits', async (c) => {
    if (!await requireAdmin()) return c.json({ error: 'Admin access required' }, 403);
    const { email, count = 1 } = await c.req.json();
    if (!email) return c.json({ error: 'email is required' }, 400);
    const n = Math.max(1, Math.min(100, parseInt(count, 10) || 1));

    const userRows = await db.select().from(tables.users)
      .where(eq(tables.users.email, email));
    if (userRows.length === 0) return c.json({ error: `No user found with email: ${email}` }, 404);

    const user = userRows[0];
    const newBalance = (user.freeInspections ?? 0) + n;
    await db.update(tables.users)
      .set({ freeInspections: newBalance })
      .where(eq(tables.users.email, email));

    console.log(`[ADMIN] Granted ${n} free inspection(s) to ${email}. New balance: ${newBalance}`);
    return c.json({
      success: true,
      email,
      granted: n,
      newBalance,
      message: `Granted ${n} free inspection(s) to ${email}. Balance is now ${newBalance}.`,
    });
  });

  // POST /api/admin/revoke-credits — remove N credits from a user
  app.post('/api/admin/revoke-credits', async (c) => {
    if (!await requireAdmin()) return c.json({ error: 'Admin access required' }, 403);
    const { email, count = 1 } = await c.req.json();
    if (!email) return c.json({ error: 'email is required' }, 400);
    const n = Math.max(1, parseInt(count, 10) || 1);

    const userRows = await db.select().from(tables.users)
      .where(eq(tables.users.email, email));
    if (userRows.length === 0) return c.json({ error: `No user found with email: ${email}` }, 404);

    const user = userRows[0];
    const newBalance = Math.max(0, (user.freeInspections ?? 0) - n);
    await db.update(tables.users)
      .set({ freeInspections: newBalance })
      .where(eq(tables.users.email, email));

    return c.json({
      success: true,
      email,
      revoked: n,
      newBalance,
      message: `Removed ${n} credit(s) from ${email}. Balance is now ${newBalance}.`,
    });
  });

  // ==================== NOTIFICATION ENDPOINTS ====================

  // Helper to send notification emails via Resend.
  // Returns a detailed result so callers/logs can diagnose Resend failures
  // (missing key, unverified sender domain, invalid recipient, network error, etc).
  async function sendNotificationEmail(
    to: string,
    subject: string,
    html: string
  ): Promise<{ ok: boolean; id?: string; error?: string; status?: number }> {
    const apiKey = secret.get('RESEND_API_KEY');
    const fromEmail = secret.get('FROM_EMAIL') || 'MeInspect <hello@meinspect.com>';

    if (!apiKey) {
      console.error('[NOTIFICATIONS] RESEND_API_KEY not configured — email NOT sent to', to);
      return { ok: false, error: 'RESEND_API_KEY not configured' };
    }

    try {
      console.log(`[NOTIFICATIONS] Sending "${subject}" to ${to} from ${fromEmail}`);
      const res = await fetch('https://api.resend.com/emails', {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${apiKey}`,
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          from: fromEmail,
          to: [to],
          subject,
          html,
        }),
      });

      const data = (await res.json().catch(() => ({}))) as any;
      if (res.ok) {
        console.log(`[NOTIFICATIONS] Resend accepted email to ${to} — id: ${data.id}`);
        return { ok: true, id: data.id, status: res.status };
      }

      // Resend rejected — surface the exact reason (e.g. unverified domain / invalid key)
      const errMsg = data.message || data.error || data.name || `HTTP ${res.status}`;
      console.error(`[NOTIFICATIONS] Resend REJECTED email to ${to} (status ${res.status}):`, errMsg, data);
      return { ok: false, error: errMsg, status: res.status };
    } catch (err) {
      console.error('[NOTIFICATIONS] Network error sending email to', to, ':', err);
      return { ok: false, error: err instanceof Error ? err.message : 'Network error' };
    }
  }

  // Shared welcome-email HTML builder
  function buildWelcomeHtml(name?: string): string {
    return `
      <div style="font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif; max-width: 600px; margin: 0 auto; padding: 32px;">
        <div style="text-align: center; margin-bottom: 32px;">
          <h1 style="font-size: 24px; color: #1e293b; margin: 0;">Welcome to MeInspect</h1>
          <p style="color: #64748b; font-size: 14px; margin-top: 8px;">Professional Property Condition Reports</p>
        </div>
        <div style="background: #f8fafc; border-radius: 12px; padding: 24px; margin-bottom: 24px;">
          <p style="color: #334155; font-size: 15px; line-height: 1.6; margin: 0;">
            Hi ${name || 'there'},<br/><br/>
            Thank you for joining MeInspect! You can now create professional property condition reports with timestamped photos, detailed assessments, and digital signatures.
          </p>
        </div>
        <div style="text-align: center;">
          <a href="https://app.meinspect.com"
             style="display: inline-block; background: #2563eb; color: white; padding: 12px 32px; border-radius: 8px; text-decoration: none; font-weight: 600; font-size: 14px;">
            Get Started
          </a>
        </div>
        <p style="color: #94a3b8; font-size: 12px; text-align: center; margin-top: 32px;">
          MeInspect — Property Condition Reports for Landlords, Tenants & Inspectors
        </p>
      </div>
    `;
  }

  // PUBLIC welcome email — safe to call right after signup without a session.
  // Native mobile (iOS/Android WebView) is cross-origin to this backend, so the
  // edge-spark auth token is NOT auto-injected there; a session-gated endpoint would
  // silently 401 and no welcome email would ever be sent. This public endpoint avoids
  // that by verifying the email against the auth-user table and only sending to a
  // genuinely-registered, recently-created account (anti-abuse), so it works reliably
  // on web AND native.
  app.post('/api/public/notifications/welcome', async (c) => {
    const { email, name } = await c.req.json().catch(() => ({}));
    if (!email) return c.json({ error: 'email is required' }, 400);

    // Verify this email belongs to a real, recently-created account
    let authUser: any = null;
    try {
      const rows = await db
        .select()
        .from(tables.esSystemAuthUser)
        .where(eq(tables.esSystemAuthUser.email, String(email).toLowerCase().trim()));
      authUser = rows[0] || null;
    } catch (e) {
      console.error('[NOTIFICATIONS] welcome lookup failed:', e);
    }

    if (!authUser) {
      // Do not leak whether an email exists; just report no-op
      console.warn('[NOTIFICATIONS] welcome requested for unknown email:', email);
      return c.json({ success: false, error: 'not_registered' }, 200);
    }

    // Only send for accounts created within the last 30 minutes (fresh signup)
    const createdAt = Number(authUser.createdAt || 0);
    const ageMs = Date.now() - createdAt;
    if (createdAt > 0 && ageMs > 30 * 60 * 1000) {
      console.warn('[NOTIFICATIONS] welcome skipped — account not fresh:', email, 'ageMs:', ageMs);
      return c.json({ success: false, error: 'not_fresh' }, 200);
    }

    const result = await sendNotificationEmail(
      authUser.email,
      'Welcome to MeInspect!',
      buildWelcomeHtml(name || authUser.name)
    );
    return c.json({ success: result.ok, error: result.error });
  });

  // Public, self-verifying "password changed" confirmation email.
  // BUG FIX (Forgot Password): the password-reset flow runs while the user is
  // logged OUT, but the original confirmation endpoint below
  // (/api/notifications/password-changed) is auth-gated and therefore always
  // returned 401 during the reset flow — so the "your password was changed"
  // email silently never sent. This public variant looks the email up in the
  // auth table and only sends to a genuinely registered account (no session or
  // token required), mirroring the public welcome-email pattern.
  app.post('/api/public/notifications/password-changed', async (c) => {
    const { email } = await c.req.json().catch(() => ({}));
    if (!email) return c.json({ error: 'email is required' }, 400);

    let authUser: any = null;
    try {
      const rows = await db
        .select()
        .from(tables.esSystemAuthUser)
        .where(eq(tables.esSystemAuthUser.email, String(email).toLowerCase().trim()));
      authUser = rows[0] || null;
    } catch (e) {
      console.error('[NOTIFICATIONS] password-changed lookup failed:', e);
    }

    if (!authUser) {
      // Do not leak whether an email exists; report a no-op.
      console.warn('[NOTIFICATIONS] password-changed requested for unknown email:', email);
      return c.json({ success: false, error: 'not_registered' }, 200);
    }

    const subject = 'MeInspect — Your Password Has Been Changed';
    const html = `
      <div style="font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif; max-width: 600px; margin: 0 auto; padding: 32px;">
        <div style="text-align: center; margin-bottom: 32px;">
          <h1 style="font-size: 24px; color: #1e293b; margin: 0;">Password Changed</h1>
        </div>
        <div style="background: #f8fafc; border-radius: 12px; padding: 24px; margin-bottom: 24px;">
          <p style="color: #334155; font-size: 15px; line-height: 1.6; margin: 0;">
            Hi,<br/><br/>
            Your MeInspect password has been successfully changed. If you did not make this change, please contact our support team immediately.
          </p>
        </div>
        <div style="background: #fef3c7; border: 1px solid #fbbf24; border-radius: 8px; padding: 16px; margin-bottom: 24px;">
          <p style="color: #92400e; font-size: 13px; margin: 0;">
            <strong>Security tip:</strong> If you didn't change your password, someone else may have accessed your account. Reset your password again immediately.
          </p>
        </div>
        <p style="color: #94a3b8; font-size: 12px; text-align: center; margin-top: 32px;">
          MeInspect — Property Condition Reports for Landlords, Tenants & Inspectors
        </p>
      </div>
    `;

    const result = await sendNotificationEmail(authUser.email, subject, html);
    return c.json({ success: result.ok, error: result.error });
  });

  // Welcome email — sent after successful signup
  app.post('/api/notifications/welcome', async (c) => {
    if (!auth.user) return c.json({ error: 'Unauthorized' }, 401);
    const { name, email } = await c.req.json();
    if (!email) return c.json({ error: 'email is required' }, 400);

    const subject = 'Welcome to MeInspect!';
    const html = `
      <div style="font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif; max-width: 600px; margin: 0 auto; padding: 32px;">
        <div style="text-align: center; margin-bottom: 32px;">
          <h1 style="font-size: 24px; color: #1e293b; margin: 0;">Welcome to MeInspect</h1>
          <p style="color: #64748b; font-size: 14px; margin-top: 8px;">Professional Property Condition Reports</p>
        </div>
        <div style="background: #f8fafc; border-radius: 12px; padding: 24px; margin-bottom: 24px;">
          <p style="color: #334155; font-size: 15px; line-height: 1.6; margin: 0;">
            Hi ${name || 'there'},<br/><br/>
            Thank you for joining MeInspect! You can now create professional property condition reports with timestamped photos, detailed assessments, and digital signatures.
          </p>
        </div>
        <div style="text-align: center;">
          <a href="${appBaseUrl}" 
             style="display: inline-block; background: #2563eb; color: white; padding: 12px 32px; border-radius: 8px; text-decoration: none; font-weight: 600; font-size: 14px;">
            Get Started
          </a>
        </div>
        <p style="color: #94a3b8; font-size: 12px; text-align: center; margin-top: 32px;">
          MeInspect — Property Condition Reports for Landlords, Tenants & Inspectors
        </p>
      </div>
    `;

    const result = await sendNotificationEmail(email, subject, html);
    return c.json({ success: result.ok, error: result.error });
  });

  // Report completion email — sent after report is generated
  app.post('/api/notifications/report-complete', async (c) => {
    if (!auth.user) return c.json({ error: 'Unauthorized' }, 401);
    const { email, name, reportName, reportId } = await c.req.json();
    if (!email || !reportId) return c.json({ error: 'email and reportId are required' }, 400);

    const shortId = reportId.slice(0, 8).toUpperCase();
    const subject = `MeInspect Report Ready: ${reportName || 'Property Report'} (RPT-${shortId})`;
    const html = `
      <div style="font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif; max-width: 600px; margin: 0 auto; padding: 32px;">
        <div style="text-align: center; margin-bottom: 32px;">
          <h1 style="font-size: 24px; color: #1e293b; margin: 0;">Report Ready</h1>
          <p style="color: #64748b; font-size: 14px; margin-top: 8px;">Your property condition report has been generated</p>
        </div>
        <div style="background: #f8fafc; border-radius: 12px; padding: 24px; margin-bottom: 24px;">
          <p style="color: #334155; font-size: 15px; line-height: 1.6; margin: 0;">
            Hi ${name || 'there'},<br/><br/>
            Your property condition report <strong>${reportName || 'Property Report'}</strong> (RPT-${shortId}) is ready for review.
          </p>
          <div style="background: white; border: 1px solid #e2e8f0; border-radius: 8px; padding: 16px; margin-top: 16px;">
            <p style="color: #64748b; font-size: 12px; margin: 0;">Report ID</p>
            <p style="color: #1e293b; font-size: 14px; font-weight: 600; margin: 4px 0 0 0;">RPT-${shortId}</p>
          </div>
        </div>
        <div style="text-align: center;">
          <a href="${reportAccessUrl(reportId)}" 
             style="display: inline-block; background: #2563eb; color: white; padding: 12px 32px; border-radius: 8px; text-decoration: none; font-weight: 600; font-size: 14px;">
            View Report
          </a>
        </div>
        <p style="color: #94a3b8; font-size: 12px; text-align: center; margin-top: 32px;">
          MeInspect — Property Condition Reports for Landlords, Tenants & Inspectors
        </p>
      </div>
    `;

    const result = await sendNotificationEmail(email, subject, html);
    return c.json({ success: result.ok, error: result.error });
  });

  // Payment success notification email
  app.post('/api/notifications/payment-success', async (c) => {
    if (!auth.user) return c.json({ error: 'Unauthorized' }, 401);
    const { email, name, amount, currency, reportId } = await c.req.json();
    if (!email || !reportId) return c.json({ error: 'email and reportId are required' }, 400);

    const subject = `Payment Successful: MeInspect Report (RPT-${reportId.slice(0, 8).toUpperCase()})`;
    const html = `
      <div style="font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif; max-width: 600px; margin: 0 auto; padding: 32px;">
        <div style="text-align: center; margin-bottom: 32px;">
          <div style="width: 64px; height: 64px; background: #f0fdf4; border-radius: 50%; display: flex; align-items: center; justify-content: center; margin: 0 auto 16px;">
            <span style="font-size: 32px;">✅</span>
          </div>
          <h1 style="font-size: 24px; color: #1e293b; margin: 0;">Payment Received</h1>
          <p style="color: #64748b; font-size: 14px; margin-top: 8px;">Thank you for your purchase</p>
        </div>
        <div style="background: #f8fafc; border-radius: 12px; padding: 24px; margin-bottom: 24px;">
          <p style="color: #334155; font-size: 15px; line-height: 1.6; margin: 0;">
            Hi ${name || 'there'},<br/><br/>
            We've successfully received your payment of <strong>${currency || 'AED'} ${amount || '500'}</strong> for the property inspection report.
          </p>
          <div style="background: white; border: 1px solid #e2e8f0; border-radius: 8px; padding: 16px; margin-top: 16px;">
            <div style="display: flex; justify-content: space-between; margin-bottom: 8px;">
              <span style="color: #64748b; font-size: 12px;">Report ID</span>
              <span style="color: #1e293b; font-size: 12px; font-weight: 600;">RPT-${reportId.slice(0, 8).toUpperCase()}</span>
            </div>
            <div style="display: flex; justify-content: space-between;">
              <span style="color: #64748b; font-size: 12px;">Amount Paid</span>
              <span style="color: #1e293b; font-size: 12px; font-weight: 600;">${currency || 'AED'} ${amount || '500'}</span>
            </div>
          </div>
        </div>
        <div style="text-align: center;">
          <a href="${reportAccessUrl(reportId)}" 
             style="display: inline-block; background: #2563eb; color: white; padding: 12px 32px; border-radius: 8px; text-decoration: none; font-weight: 600; font-size: 14px;">
            Access Your Report
          </a>
        </div>
        <p style="color: #94a3b8; font-size: 12px; text-align: center; margin-top: 32px;">
          MeInspect — Property Condition Reports for Landlords, Tenants & Inspectors
        </p>
      </div>
    `;

    const result = await sendNotificationEmail(email, subject, html);
    return c.json({ success: result.ok, error: result.error });
  });

  // Password changed notification email
  app.post('/api/notifications/password-changed', async (c) => {
    if (!auth.user) return c.json({ error: 'Unauthorized' }, 401);
    const { email } = await c.req.json();
    if (!email) return c.json({ error: 'email is required' }, 400);

    const subject = 'MeInspect — Your Password Has Been Changed';
    const html = `
      <div style="font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif; max-width: 600px; margin: 0 auto; padding: 32px;">
        <div style="text-align: center; margin-bottom: 32px;">
          <h1 style="font-size: 24px; color: #1e293b; margin: 0;">Password Changed</h1>
        </div>
        <div style="background: #f8fafc; border-radius: 12px; padding: 24px; margin-bottom: 24px;">
          <p style="color: #334155; font-size: 15px; line-height: 1.6; margin: 0;">
            Hi,<br/><br/>
            Your MeInspect password has been successfully changed. If you did not make this change, please contact our support team immediately.
          </p>
        </div>
        <div style="background: #fef3c7; border: 1px solid #fbbf24; border-radius: 8px; padding: 16px; margin-bottom: 24px;">
          <p style="color: #92400e; font-size: 13px; margin: 0;">
            <strong>Security tip:</strong> If you didn't change your password, someone else may have accessed your account. Change your password again and enable two-factor authentication if available.
          </p>
        </div>
        <p style="color: #94a3b8; font-size: 12px; text-align: center; margin-top: 32px;">
          MeInspect — Property Condition Reports for Landlords, Tenants & Inspectors
        </p>
      </div>
    `;

    const result = await sendNotificationEmail(email, subject, html);
    return c.json({ success: result.ok, error: result.error });
  });

  return app;
}

# @edgespark/cli

EdgeSpark CLI - Create and manage your EdgeSpark projects.

## Installation

```bash
npm install -g @edgespark/cli
```

## Usage

### Initialize a new project

```bash
# Default (creates AGENT.md)
edgespark init my-project

# With specific AI agent
edgespark init my-project --agent claude    # Creates CLAUDE.md
edgespark init my-project -a gemini         # Creates GEMINI.md

# Via environment variable
EDGESPARK_AGENT_NAME=claude edgespark init my-project
```

**Agent options:** `claude`, `codex`, `gemini`, `paintress`

### Pull schema from EdgeSpark platform

```bash
edgespark pull
```

Pulls the latest database and storage schema from your EdgeSpark project and generates TypeScript files in `src/__generated__/`.

### Help

```bash
# General help
edgespark --help

# Command-specific help
edgespark init --help
edgespark pull --help
```

## Commands

| Command | Description |
|---------|-------------|
| `edgespark init <name>` | Initialize a new EdgeSpark project |
| `edgespark pull` | Pull schema from EdgeSpark platform |

## Project Structure

After running `edgespark init`, your project will have:

```
my-project/
├── src/
│   ├── index.ts              # Your API routes (Hono)
│   ├── __generated__/        # Schema files (pulled from platform)
│   │   ├── index.ts          # Barrel exports
│   │   ├── db_schema.ts      # Database schema (Drizzle ORM)
│   │   ├── db_relations.ts   # Relation definitions (if any)
│   │   └── storage_schema.ts # Storage bucket definitions
│   └── types/
│       └── server-sdk.d.ts   # EdgeSpark SDK type definitions
├── edgespark.toml            # Project configuration
├── package.json
├── tsconfig.json
└── AGENT.md                  # AI coding agent instructions
```

## Development

```bash
npm run build:dev   # tsc (for development/tests)
npm run dev         # tsc --watch
npm test            # run tests
npm run link        # build bundle + npm link for local testing
```

## Publishing

`prepublishOnly` automatically runs esbuild + copies templates before any publish.

### 1. Beta release

```bash
npm version <version>-beta.0       # first beta for a new version (manual)
npm publish --tag beta             # publish to "beta" tag (latest untouched)
```

### 2. Iterate on beta

```bash
npm version prerelease             # auto-bumps beta.0 → beta.1 → beta.2
npm publish --tag beta
```

### 3. Test beta

```bash
npm install -g @edgespark/cli@beta # install globally
edgespark --version                # verify
npx @edgespark/cli@beta --version  # or test without global install
```

### 4. Graduate to release

```bash
npm version patch                  # 0.0.X-beta.N → 0.0.X (clean version)
npm publish                        # publishes to "latest" tag
```

### Version commands cheat sheet

| Command | Example |
|---------|---------|
| `npm version <version>-beta.0` | First beta (manual) |
| `npm version prerelease` | `beta.0` → `beta.1` |
| `npm version patch` | `0.0.10-beta.2` → `0.0.10` |
| `npm version minor` | → `0.1.0` |
| `npm version major` | → `1.0.0` |

## License

MIT

/**
 * EdgeSpark SDK module declarations.
 * Run `edgespark pull types` to populate this file.
 */
export {};
